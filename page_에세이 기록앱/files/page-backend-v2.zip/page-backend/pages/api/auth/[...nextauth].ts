import NextAuth from 'next-auth'
import GoogleProvider from 'next-auth/providers/google'
import KakaoProvider from 'next-auth/providers/kakao'
import { createClient } from '@supabase/supabase-js'

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  { auth: { autoRefreshToken: false, persistSession: false } }
)

export const authOptions = {
  providers: [
    GoogleProvider({
      clientId:     process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    KakaoProvider({
      clientId:     process.env.KAKAO_CLIENT_ID!,
      clientSecret: process.env.KAKAO_CLIENT_SECRET!,
    }),
  ],

  callbacks: {
    async signIn({ user, account }: any) {
      if (!account) return false
      try {
        const { data: existing } = await supabaseAdmin
          .from('users').select('id')
          .eq('provider', account.provider)
          .eq('provider_id', account.providerAccountId)
          .single()
        if (existing) {
          await supabaseAdmin.from('users')
            .update({ last_login: new Date().toISOString() })
            .eq('id', existing.id)
        } else {
          await supabaseAdmin.from('users').insert({
            email:       user.email || '',
            name:        user.name  || '유저',
            avatar_url:  user.image || '',
            provider:    account.provider,
            provider_id: account.providerAccountId,
            plan:        'free',
            essay_count: 0,
          })
        }
      } catch (err) {
        console.error('signIn error:', err)
      }
      return true
    },

    async jwt({ token, account }: any) {
      if (account) {
        try {
          const { data: dbUser } = await supabaseAdmin
            .from('users').select('id, plan')
            .eq('provider', account.provider)
            .eq('provider_id', account.providerAccountId)
            .single()
          if (dbUser) {
            token.userId   = dbUser.id
            token.plan     = dbUser.plan || 'free'
            token.provider = account.provider
          }
        } catch (err) {
          console.error('jwt error:', err)
        }
      }
      return token
    },

    async session({ session, token }: any) {
      if (session.user) {
        session.user.id       = token.userId   || ''
        session.user.plan     = token.plan     || 'free'
        session.user.provider = token.provider || ''
      }
      return session
    },
  },

  pages: {
    signIn: '/auth/login',
    error:  '/auth/error',
  },

  session: {
    strategy: 'jwt' as const,
    maxAge:   30 * 24 * 60 * 60,
  },

  secret: process.env.NEXTAUTH_SECRET,
}

export default NextAuth(authOptions)
