import type { NextApiRequest, NextApiResponse } from 'next'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const { plan, amount } = req.body

  // Stripe가 설정되지 않은 경우 안내
  if (!process.env.STRIPE_SECRET_KEY) {
    return res.status(200).json({
      url: null,
      message: 'Stripe 설정이 필요합니다. STRIPE_SECRET_KEY 환경변수를 설정하세요.'
    })
  }

  try {
    const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY)
    const priceMap: Record<string, number> = {
      pro:     990,   // $9.90 USD
      premium: 1990,  // $19.90 USD
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: {
            name: `Page.ai ${plan === 'pro' ? 'Pro' : 'Premium'} Plan`,
            description: plan === 'pro' ? '무제한 AI 에세이 + 고급 기능' : '모든 기능 + 우선 지원',
          },
          unit_amount: priceMap[plan] || 990,
          recurring: { interval: 'month' },
        },
        quantity: 1,
      }],
      mode: 'subscription',
      success_url: 'https://baro-a.github.io/page-ai?loggedIn=1&payment=success',
      cancel_url:  'https://baro-a.github.io/page-ai?payment=cancel',
      metadata: { plan, userId: 'user' },
    })

    return res.status(200).json({ url: session.url })
  } catch (err: any) {
    console.error('Stripe error:', err)
    return res.status(500).json({ error: err.message })
  }
}
