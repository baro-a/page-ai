import { GetServerSideProps } from 'next'
import { getServerSession } from 'next-auth'
import { authOptions } from '../api/auth/[...nextauth]'

// 로그인 성공 후 유저 정보를 URL에 담아 GitHub Pages로 리디렉션
export default function Callback() {
  return null
}

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const session = await getServerSession(ctx.req, ctx.res, authOptions)

  const FRONTEND_URL = 'https://baro-a.github.io/page-ai'

  if (!session?.user) {
    return { redirect: { destination: FRONTEND_URL + '?loginError=1', permanent: false } }
  }

  const user = session.user as any
  const params = new URLSearchParams({
    loggedIn:  '1',
    name:      user.name     || '',
    email:     user.email    || '',
    avatar:    user.image    || '',
    plan:      user.plan     || 'free',
    provider:  user.provider || '',
    id:        user.id       || '',
  })

  return {
    redirect: {
      destination: FRONTEND_URL + '?' + params.toString(),
      permanent: false,
    }
  }
}
