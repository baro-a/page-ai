import { useRouter } from 'next/router'

export default function AuthError() {
  const router = useRouter()
  const error = router.query.error as string

  const messages: Record<string, string> = {
    OAuthSignin:        '로그인 요청 중 오류가 발생했습니다',
    OAuthCallback:      '소셜 로그인 처리 중 오류가 발생했습니다',
    OAuthCreateAccount: '계정 생성에 실패했습니다',
    AccessDenied:       '접근이 거부되었습니다',
    Default:            '로그인 중 오류가 발생했습니다',
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: '#151311',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'Manrope, sans-serif',
      color: '#e8e1dd',
    }}>
      <div style={{
        background: '#1e0f06',
        border: '1px solid rgba(200,168,74,0.2)',
        borderRadius: 20,
        padding: '40px 36px',
        textAlign: 'center',
        maxWidth: 380,
      }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>⚠️</div>
        <h2 style={{ fontFamily: 'Georgia, serif', fontStyle: 'italic', color: '#C8A84A', marginBottom: 12 }}>
          로그인 오류
        </h2>
        <p style={{ color: 'rgba(200,168,74,0.6)', fontSize: 14, lineHeight: 1.6, marginBottom: 24 }}>
          {messages[error] || messages.Default}
        </p>
        <button
          onClick={() => router.push('/auth/login')}
          style={{
            padding: '12px 28px',
            background: 'linear-gradient(135deg, #C8A84A, #8B6520)',
            color: '#0A0400',
            border: 'none',
            borderRadius: 100,
            fontWeight: 800,
            fontSize: 12,
            letterSpacing: '0.1em',
            cursor: 'pointer',
          }}
        >
          다시 시도
        </button>
      </div>
    </div>
  )
}
