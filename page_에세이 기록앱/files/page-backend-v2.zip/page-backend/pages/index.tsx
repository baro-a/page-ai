import { useEffect } from 'react'

export default function Home() {
  useEffect(() => {
    // 루트 접속 시 로그인 페이지로 리디렉션
    window.location.href = '/auth/login'
  }, [])
  return null
}
