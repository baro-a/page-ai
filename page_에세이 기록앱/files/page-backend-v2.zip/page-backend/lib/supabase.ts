import { createClient } from '@supabase/supabase-js'

// ── 공개 클라이언트 (프론트엔드용) ───────────────
export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

// ── 관리자 클라이언트 (백엔드 전용) ──────────────
export const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  { auth: { autoRefreshToken: false, persistSession: false } }
)

// ── DB 타입 정의 ──────────────────────────────────
export interface User {
  id: string
  email: string
  name: string
  avatar_url: string
  provider: 'google' | 'kakao' | 'naver' | 'facebook'
  provider_id: string
  plan: 'free' | 'pro' | 'premium'
  essay_count: number
  created_at: string
  last_login: string
}

export interface Essay {
  id: string
  user_id: string
  title: string
  body: string
  emotion: string
  category: string
  format: string
  is_webtoon: boolean
  image_url?: string
  image_thumb?: string
  location?: string
  date_label?: string
  created_at: string
}

export interface Subscription {
  id: string
  user_id: string
  plan: 'pro' | 'premium'
  status: 'active' | 'cancelled' | 'expired'
  amount: number
  payment_method: string
  toss_order_id: string
  toss_payment_key: string
  started_at: string
  expires_at: string
}
