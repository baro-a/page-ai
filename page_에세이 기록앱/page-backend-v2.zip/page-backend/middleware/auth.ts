import { getServerSession } from 'next-auth'
import { authOptions } from '@/pages/api/auth/[...nextauth]'
import type { NextApiRequest, NextApiResponse } from 'next'

// ── 인증된 사용자만 통과시키는 미들웨어 ──────────
export async function withAuth(
  req: NextApiRequest,
  res: NextApiResponse,
  handler: (req: NextApiRequest, res: NextApiResponse, userId: string) => Promise<void>
) {
  const session = await getServerSession(req, res, authOptions)

  if (!session?.user?.id) {
    return res.status(401).json({
      error: '로그인이 필요합니다',
      code: 'UNAUTHORIZED',
    })
  }

  return handler(req, res, session.user.id)
}

// ── 플랜 체크 미들웨어 ────────────────────────────
export async function withPlan(
  req: NextApiRequest,
  res: NextApiResponse,
  requiredPlan: 'pro' | 'premium',
  handler: (req: NextApiRequest, res: NextApiResponse) => Promise<void>
) {
  const session = await getServerSession(req, res, authOptions)

  if (!session?.user?.id) {
    return res.status(401).json({ error: '로그인이 필요합니다' })
  }

  const planOrder = { free: 0, pro: 1, premium: 2 }
  const userPlan  = (session.user.plan || 'free') as keyof typeof planOrder
  const required  = requiredPlan as keyof typeof planOrder

  if (planOrder[userPlan] < planOrder[required]) {
    return res.status(403).json({
      error: `${requiredPlan === 'pro' ? 'Pro' : 'Premium'} 플랜이 필요합니다`,
      code: 'PLAN_REQUIRED',
      requiredPlan,
      currentPlan: userPlan,
    })
  }

  return handler(req, res)
}
