-- ================================================
-- Page.ai Supabase DB 스키마
-- Supabase SQL Editor에서 순서대로 실행
-- ================================================

-- UUID 확장 활성화
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ──────────────────────────────────────────────
-- 1. 유저 테이블
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  email           VARCHAR(255) UNIQUE,
  name            VARCHAR(255),
  avatar_url      TEXT,
  provider        VARCHAR(50) NOT NULL,   -- 'google'|'kakao'|'naver'|'facebook'
  provider_id     VARCHAR(255) NOT NULL,  -- 각 플랫폼 고유 ID
  plan            VARCHAR(20) DEFAULT 'free',  -- 'free'|'pro'|'premium'
  essay_count     INTEGER DEFAULT 0,      -- 이번 달 생성 횟수
  count_reset_at  TIMESTAMP DEFAULT NOW(), -- 카운트 초기화 기준일
  created_at      TIMESTAMP DEFAULT NOW(),
  last_login      TIMESTAMP DEFAULT NOW(),
  UNIQUE(provider, provider_id)
);

-- 유저 Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "유저 본인만 조회/수정" ON users
  FOR ALL USING (auth.uid() = id);

-- ──────────────────────────────────────────────
-- 2. 에세이 테이블
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS essays (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id       UUID REFERENCES users(id) ON DELETE CASCADE,
  title         VARCHAR(500),
  body          TEXT,
  emotion       VARCHAR(100),
  category      VARCHAR(100) DEFAULT '일상',
  format        VARCHAR(50) DEFAULT '에세이',
  is_webtoon    BOOLEAN DEFAULT FALSE,
  image_url     TEXT,          -- Supabase Storage URL (큰 이미지)
  image_thumb   TEXT,          -- 썸네일 base64 (150KB 이하)
  location      VARCHAR(200),
  date_label    VARCHAR(100),  -- "4월 17일" 형태
  created_at    TIMESTAMP DEFAULT NOW(),
  updated_at    TIMESTAMP DEFAULT NOW()
);

-- 에세이 인덱스
CREATE INDEX idx_essays_user_id ON essays(user_id);
CREATE INDEX idx_essays_category ON essays(category);
CREATE INDEX idx_essays_created_at ON essays(created_at DESC);

-- 에세이 Row Level Security
ALTER TABLE essays ENABLE ROW LEVEL SECURITY;
CREATE POLICY "본인 에세이만 접근" ON essays
  FOR ALL USING (auth.uid() = user_id);

-- ──────────────────────────────────────────────
-- 3. 구독/결제 테이블
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subscriptions (
  id               UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id          UUID REFERENCES users(id) ON DELETE CASCADE,
  plan             VARCHAR(20) NOT NULL,   -- 'pro'|'premium'
  status           VARCHAR(20) DEFAULT 'active', -- 'active'|'cancelled'|'expired'
  amount           INTEGER NOT NULL,       -- 결제 금액 (원)
  payment_method   VARCHAR(50),            -- 'card'|'kakao_pay'|'naver_pay'
  toss_order_id    VARCHAR(100) UNIQUE,    -- 토스 주문번호
  toss_payment_key VARCHAR(200),           -- 토스 결제키 (환불용)
  started_at       TIMESTAMP DEFAULT NOW(),
  expires_at       TIMESTAMP,
  cancelled_at     TIMESTAMP,
  created_at       TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "본인 구독만 조회" ON subscriptions
  FOR SELECT USING (auth.uid() = user_id);

-- ──────────────────────────────────────────────
-- 4. 결제 로그 (감사 추적용)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payment_logs (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id       UUID REFERENCES users(id),
  event_type    VARCHAR(50),  -- 'payment_success'|'payment_fail'|'refund'
  order_id      VARCHAR(100),
  payment_key   VARCHAR(200),
  amount        INTEGER,
  plan          VARCHAR(20),
  raw_response  JSONB,        -- 토스 응답 원문
  created_at    TIMESTAMP DEFAULT NOW()
);

-- ──────────────────────────────────────────────
-- 5. 유용한 함수들
-- ──────────────────────────────────────────────

-- 월별 카운트 자동 초기화 함수
CREATE OR REPLACE FUNCTION reset_monthly_count()
RETURNS TRIGGER AS $$
BEGIN
  -- 새 달이 시작되면 카운트 초기화
  IF EXTRACT(MONTH FROM NOW()) != EXTRACT(MONTH FROM NEW.count_reset_at) THEN
    NEW.essay_count = 0;
    NEW.count_reset_at = NOW();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER monthly_count_reset
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION reset_monthly_count();

-- 에세이 작성 시 카운트 증가 함수
CREATE OR REPLACE FUNCTION increment_essay_count(p_user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  v_user users%ROWTYPE;
  v_limit INTEGER;
BEGIN
  SELECT * INTO v_user FROM users WHERE id = p_user_id;
  
  -- 플랜별 제한
  v_limit := CASE v_user.plan
    WHEN 'free'    THEN 10
    WHEN 'pro'     THEN 9999
    WHEN 'premium' THEN 9999
    ELSE 10
  END;
  
  -- 이번 달 카운트 초과 확인
  IF v_user.essay_count >= v_limit THEN
    RETURN FALSE;  -- 제한 초과
  END IF;
  
  -- 카운트 증가
  UPDATE users SET essay_count = essay_count + 1 WHERE id = p_user_id;
  RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ──────────────────────────────────────────────
-- 6. 플랜 자동 만료 처리 (Cron Job용)
-- ──────────────────────────────────────────────
-- Supabase Cron에서 매일 자정 실행:
-- SELECT expire_subscriptions();

CREATE OR REPLACE FUNCTION expire_subscriptions()
RETURNS void AS $$
BEGIN
  -- 만료된 구독 상태 변경
  UPDATE subscriptions 
  SET status = 'expired'
  WHERE status = 'active' 
    AND expires_at < NOW();
  
  -- 만료된 유저 플랜 초기화
  UPDATE users 
  SET plan = 'free'
  WHERE id IN (
    SELECT user_id FROM subscriptions 
    WHERE status = 'expired' 
      AND expires_at < NOW()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
