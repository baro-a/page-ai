# 🚀 Page.ai 배포 가이드 — Phase 2 실행 순서

---

## STEP 1: Supabase 프로젝트 생성

1. https://supabase.com 접속 → New Project
2. **Project name**: page-ai
3. **Database password**: 강력한 비밀번호 저장
4. **Region**: Northeast Asia (Seoul)

### DB 스키마 적용
- Supabase Dashboard → SQL Editor
- `sql/schema.sql` 전체 붙여넣기 → Run

### 키 확인
- Settings → API → `anon key`, `service_role key`
- Settings → API → `Project URL`

---

## STEP 2: OAuth 앱 등록

### Google
```
1. https://console.cloud.google.com
2. 새 프로젝트 생성 → OAuth 동의 화면 설정
3. 사용자 인증 정보 → OAuth 클라이언트 ID 생성
4. 애플리케이션 유형: 웹 애플리케이션
5. 승인된 리디렉션 URI:
   https://your-domain.vercel.app/api/auth/callback/google
6. CLIENT_ID, CLIENT_SECRET 저장
```

### 카카오 (가장 중요 — 한국 유저 1위)
```
1. https://developers.kakao.com → 내 애플리케이션 → 앱 추가
2. 앱 이름: Page, 회사: 개인
3. 플랫폼 → Web → 사이트 도메인:
   https://your-domain.vercel.app
4. 카카오 로그인 → 활성화
5. Redirect URI:
   https://your-domain.vercel.app/api/auth/callback/kakao
6. 동의항목: nickname(필수), profile_image(선택), account_email(선택)
7. 앱 키 → REST API 키 저장
```

### 네이버
```
1. https://developers.naver.com → Application → 애플리케이션 등록
2. 사용 API: 네이버 로그인
3. 서비스 URL: https://your-domain.vercel.app
4. Callback URL:
   https://your-domain.vercel.app/api/auth/callback/naver
5. Client ID, Client Secret 저장
```

### Facebook
```
1. https://developers.facebook.com → 내 앱 → 앱 만들기
2. 소비자 → Facebook 로그인 추가
3. 유효한 OAuth 리디렉션 URI:
   https://your-domain.vercel.app/api/auth/callback/facebook
4. App ID, App Secret 저장
5. ⚠️ 앱 검수 필요 (퍼블릭 배포 시)
```

---

## STEP 3: 토스페이먼츠 계정

```
1. https://developers.tosspayments.com 가입
2. 테스트 → 내 개발 정보 → API 키 확인
   - Client Key: test_ck_xxxx (프론트용)
   - Secret Key: test_sk_xxxx (백엔드용)
3. 운영 전환 시: 비즈니스 인증 필요 (사업자등록증 또는 개인)
4. Webhook URL 등록:
   https://your-domain.vercel.app/api/payment/webhook
```

---

## STEP 4: Vercel 배포

```bash
# 1. GitHub 저장소 생성 + 코드 푸시
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/username/page-ai-backend.git
git push -u origin main

# 2. Vercel 연결
# https://vercel.com → New Project → GitHub 저장소 선택

# 3. 환경변수 설정 (Vercel Dashboard → Settings → Environment Variables)
# .env.local.example의 모든 항목 입력
```

### Vercel 환경변수 입력 목록
```
NEXTAUTH_URL              = https://your-domain.vercel.app
NEXTAUTH_SECRET           = (openssl rand -base64 32 실행값)
NEXT_PUBLIC_SUPABASE_URL  = https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = ...
SUPABASE_SERVICE_ROLE_KEY = ...
GOOGLE_CLIENT_ID          = ...
GOOGLE_CLIENT_SECRET      = ...
KAKAO_CLIENT_ID           = ...
KAKAO_CLIENT_SECRET       = (없으면 빈 문자열 'none')
NAVER_CLIENT_ID           = ...
NAVER_CLIENT_SECRET       = ...
FACEBOOK_CLIENT_ID        = ...
FACEBOOK_CLIENT_SECRET    = ...
TOSS_CLIENT_KEY           = test_ck_...
TOSS_SECRET_KEY           = test_sk_...
NEXT_PUBLIC_TOSS_CLIENT_KEY = test_ck_...
GEMMA_API_KEY             = AIzaSy...
CLAUDE_API_KEY            = sk-ant-...
```

---

## STEP 5: index.html 연결

배포 완료 후 index.html 수정:

```javascript
// 현재 (시뮬레이션)
const API_BASE_URL = 'https://your-page-app.vercel.app'

// 배포 후 실제 URL로 교체
const API_BASE_URL = 'https://page-ai-backend.vercel.app'
```

loginWith 함수에서 시뮬레이션 코드 제거:
```javascript
// 이 부분 제거
setTimeout(()=>{ ... }, 1000);

// 주석 해제
window.location.href = `${API_BASE_URL}/api/auth/signin/${provider}`;
```

---

## STEP 6: 테스트 체크리스트

- [ ] 구글 로그인 → 서재 진입
- [ ] 카카오 로그인 → 서재 진입
- [ ] 에세이 생성 → DB 저장 확인
- [ ] 무료 플랜 10편 제한 확인
- [ ] 토스 테스트 결제 (카드번호: 4242-4242-4242-4242)
- [ ] Pro 업그레이드 후 무제한 확인
- [ ] 구독 해지 → Free 복귀 확인

---

## 비용 예상 (월)

| 서비스 | 무료 | 유료 전환 기준 |
|--------|------|----------------|
| Vercel | 무료 | 트래픽 100GB 초과 시 |
| Supabase | 무료 (500MB DB) | 유저 50,000명 초과 시 |
| 토스페이먼츠 | 수수료 3.3% | 없음 |
| Gemma API | 1,500회/월 무료 | 초과 시 소량 과금 |

**초기 운영비: 0원** ✅
