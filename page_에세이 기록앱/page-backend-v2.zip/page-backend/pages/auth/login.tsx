import { signIn, getSession } from 'next-auth/react'
import { GetServerSideProps } from 'next'
import Head from 'next/head'
import { useState } from 'react'

interface LoginPageProps {
  callbackUrl: string
  error?: string
}

const PROVIDERS = [
  {
    id: 'google',
    name: 'Google',
    color: '#fff',
    textColor: '#333',
    border: '1px solid #ddd',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24">
        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
      </svg>
    ),
  },
  {
    id: 'kakao',
    name: '카카오',
    color: '#FEE500',
    textColor: '#191919',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24">
        <path fill="#191919" d="M12 3C7.03 3 3 6.36 3 10.5c0 2.67 1.6 5.02 4.02 6.42l-.98 3.63a.38.38 0 0 0 .56.42l4.28-2.85c.37.03.74.05 1.12.05 4.97 0 9-3.36 9-7.5S16.97 3 12 3z"/>
      </svg>
    ),
  },
  {
    id: 'naver',
    name: '네이버',
    color: '#03C75A',
    textColor: '#fff',
    icon: <span style={{ fontWeight: 900, fontSize: 16, color: '#fff' }}>N</span>,
  },
  {
    id: 'facebook',
    name: 'Facebook',
    color: '#1877F2',
    textColor: '#fff',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24">
        <path fill="#fff" d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.095 10.125 24v-8.437H7.078v-3.49h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.49h-2.796V24C19.612 23.095 24 18.1 24 12.073z"/>
      </svg>
    ),
  },
]

const ERROR_MESSAGES: Record<string, string> = {
  OAuthSignin:    '로그인 요청 중 오류가 발생했습니다',
  OAuthCallback:  '소셜 로그인 처리 중 오류가 발생했습니다',
  OAuthCreateAccount: '계정 생성에 실패했습니다',
  AccessDenied:   '접근이 거부되었습니다',
  Default:        '로그인 중 오류가 발생했습니다. 다시 시도해주세요',
}

export default function LoginPage({ callbackUrl, error }: LoginPageProps) {
  const [loading, setLoading] = useState<string | null>(null)

  const handleLogin = async (providerId: string) => {
    setLoading(providerId)
    try {
      await signIn(providerId, { callbackUrl })
    } catch {
      setLoading(null)
    }
  }

  return (
    <>
      <Head>
        <title>로그인 — Page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #0D0702, #1A0E06)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '20px',
        fontFamily: "'Manrope', 'Noto Sans KR', sans-serif",
      }}>
        <div style={{
          background: 'linear-gradient(145deg, #130a04, #1e0f06)',
          border: '1px solid rgba(200,168,74,0.2)',
          borderRadius: 28, padding: '40px 36px',
          width: '100%', maxWidth: 420,
          boxShadow: '0 32px 80px rgba(0,0,0,0.7)',
        }}>
          {/* 로고 */}
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <div style={{
              fontFamily: "'Newsreader', Georgia, serif",
              fontStyle: 'italic', fontSize: 32,
              color: '#C8A84A', marginBottom: 6,
            }}>Page</div>
            <div style={{
              fontSize: 10, fontWeight: 700, letterSpacing: '0.2em',
              textTransform: 'uppercase', color: 'rgba(200,168,74,0.4)',
            }}>당신의 인생 도서관</div>
          </div>

          {/* 오류 메시지 */}
          {error && (
            <div style={{
              background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)',
              borderRadius: 12, padding: '12px 16px', marginBottom: 20,
              color: 'rgba(239,68,68,0.9)', fontSize: 13, textAlign: 'center',
            }}>
              {ERROR_MESSAGES[error] || ERROR_MESSAGES.Default}
            </div>
          )}

          <div style={{ fontSize: 12, color: 'rgba(200,168,74,0.5)', textAlign: 'center', marginBottom: 20 }}>
            소셜 계정으로 간편하게 시작하세요
          </div>

          {/* 소셜 버튼들 */}
          {PROVIDERS.map((p) => (
            <button
              key={p.id}
              onClick={() => handleLogin(p.id)}
              disabled={!!loading}
              style={{
                width: '100%', padding: '14px 20px', marginBottom: 10,
                borderRadius: 14, border: p.border || 'none',
                background: loading === p.id ? 'rgba(200,168,74,0.1)' : p.color,
                color: p.textColor, cursor: loading ? 'wait' : 'pointer',
                display: 'flex', alignItems: 'center', gap: 14,
                fontSize: 13, fontWeight: 700,
                transition: 'all 0.2s', opacity: loading && loading !== p.id ? 0.5 : 1,
              }}
            >
              <span style={{ width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {loading === p.id ? '⏳' : p.icon}
              </span>
              <span style={{ flex: 1 }}>
                {loading === p.id ? '로그인 중...' : `${p.name}로 계속하기`}
              </span>
              <span style={{ opacity: 0.5 }}>→</span>
            </button>
          ))}

          {/* 이용약관 */}
          <div style={{
            marginTop: 20, fontSize: 10, color: 'rgba(200,168,74,0.25)',
            textAlign: 'center', lineHeight: 1.7,
          }}>
            로그인하면{' '}
            <a href="/terms" style={{ color: 'rgba(200,168,74,0.45)' }}>이용약관</a>
            {' '}및{' '}
            <a href="/privacy" style={{ color: 'rgba(200,168,74,0.45)' }}>개인정보처리방침</a>
            에 동의합니다.
          </div>
        </div>
      </div>
    </>
  )
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const session = await getSession(context)
  if (session) {
    return { redirect: { destination: '/', permanent: false } }
  }

  return {
    props: {
      callbackUrl: (context.query.callbackUrl as string) || '/',
      error: (context.query.error as string) || null,
    },
  }
}
