import type { NextApiRequest, NextApiResponse } from 'next'
import { getServerSession } from 'next-auth'
import { authOptions } from '../auth/[...nextauth]'
import { supabaseAdmin } from '@/lib/supabase'

// 무료 플랜 월 제한
const FREE_LIMIT = Number(process.env.FREE_PLAN_LIMIT || 10)

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions)
  if (!session?.user?.id) {
    return res.status(401).json({ error: '로그인이 필요합니다' })
  }

  const userId = session.user.id

  // ── GET: 에세이 목록 조회 ─────────────────────
  if (req.method === 'GET') {
    const { category, limit = '50', offset = '0' } = req.query

    let query = supabaseAdmin
      .from('essays')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(Number(offset), Number(offset) + Number(limit) - 1)

    if (category && category !== 'all') {
      query = query.eq('category', category)
    }

    const { data, error, count } = await query
    if (error) return res.status(500).json({ error: error.message })
    return res.status(200).json({ essays: data, total: count })
  }

  // ── POST: 에세이 저장 ─────────────────────────
  if (req.method === 'POST') {
    // 사용량 제한 확인 (무료 플랜)
    const { data: user } = await supabaseAdmin
      .from('users')
      .select('plan, essay_count, count_reset_at')
      .eq('id', userId)
      .single()

    if (user?.plan === 'free') {
      // 이번 달 리셋 확인
      const resetDate = new Date(user.count_reset_at)
      const now = new Date()
      const isSameMonth = resetDate.getMonth() === now.getMonth() &&
                          resetDate.getFullYear() === now.getFullYear()

      const currentCount = isSameMonth ? user.essay_count : 0

      if (currentCount >= FREE_LIMIT) {
        return res.status(403).json({
          error: `무료 플랜은 월 ${FREE_LIMIT}편까지 작성 가능합니다`,
          code: 'PLAN_LIMIT_EXCEEDED',
          current: currentCount,
          limit: FREE_LIMIT,
        })
      }
    }

    const { title, body, emotion, category, format, is_webtoon, image_thumb, location } = req.body

    if (!title || !body) {
      return res.status(400).json({ error: '제목과 내용은 필수입니다' })
    }

    // 에세이 저장
    const { data: essay, error } = await supabaseAdmin
      .from('essays')
      .insert({
        user_id: userId,
        title,
        body,
        emotion: emotion || '',
        category: category || '일상',
        format: format || '에세이',
        is_webtoon: is_webtoon || false,
        image_thumb: image_thumb || null,  // 150KB 이하 썸네일
        location: location || '',
        date_label: new Date().toLocaleDateString('ko-KR', { month: 'long', day: 'numeric' }),
      })
      .select()
      .single()

    if (error) return res.status(500).json({ error: error.message })

    // 사용 횟수 증가
    await supabaseAdmin.rpc('increment_essay_count', { p_user_id: userId })

    return res.status(201).json({ essay })
  }

  // ── DELETE: 에세이 삭제 ───────────────────────
  if (req.method === 'DELETE') {
    const { id } = req.query
    const { error } = await supabaseAdmin
      .from('essays')
      .delete()
      .eq('id', id)
      .eq('user_id', userId) // 본인 것만 삭제 가능

    if (error) return res.status(500).json({ error: error.message })
    return res.status(200).json({ success: true })
  }

  return res.status(405).end()
}
