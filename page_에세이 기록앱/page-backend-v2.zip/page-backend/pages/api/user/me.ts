import type { NextApiRequest, NextApiResponse } from 'next'
import { withAuth } from '@/middleware/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  return withAuth(req, res, async (req, res, userId) => {

    // ── GET: 내 프로필 + 사용량 조회 ─────────────
    if (req.method === 'GET') {
      const { data: user, error } = await supabaseAdmin
        .from('users')
        .select(`
          id, email, name, avatar_url, provider, plan,
          essay_count, count_reset_at, created_at, last_login
        `)
        .eq('id', userId)
        .single()

      if (error || !user) {
        return res.status(404).json({ error: '유저를 찾을 수 없습니다' })
      }

      // 이번 달 에세이 수 계산
      const resetDate  = new Date(user.count_reset_at)
      const now        = new Date()
      const isSameMonth =
        resetDate.getMonth() === now.getMonth() &&
        resetDate.getFullYear() === now.getFullYear()

      const thisMonthCount = isSameMonth ? user.essay_count : 0
      const planLimit      = user.plan === 'free' ? 10 : 9999

      // 구독 정보 조회
      const { data: subscription } = await supabaseAdmin
        .from('subscriptions')
        .select('plan, status, expires_at, amount')
        .eq('user_id', userId)
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(1)
        .single()

      return res.status(200).json({
        user: {
          id:        user.id,
          email:     user.email,
          name:      user.name,
          avatar:    user.avatar_url,
          provider:  user.provider,
          plan:      user.plan,
          createdAt: user.created_at,
        },
        usage: {
          thisMonth: thisMonthCount,
          limit:     planLimit,
          remaining: Math.max(0, planLimit - thisMonthCount),
          resetAt:   new Date(now.getFullYear(), now.getMonth() + 1, 1).toISOString(),
        },
        subscription: subscription || null,
      })
    }

    // ── PUT: 프로필 업데이트 (이름만 변경 가능) ──
    if (req.method === 'PUT') {
      const { name } = req.body
      if (!name || name.trim().length < 1) {
        return res.status(400).json({ error: '이름을 입력해주세요' })
      }

      const { error } = await supabaseAdmin
        .from('users')
        .update({ name: name.trim() })
        .eq('id', userId)

      if (error) return res.status(500).json({ error: error.message })
      return res.status(200).json({ success: true })
    }

    return res.status(405).end()
  })
}
