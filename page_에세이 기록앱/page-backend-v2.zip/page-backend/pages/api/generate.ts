import type { NextApiRequest, NextApiResponse } from 'next'
import { getServerSession } from 'next-auth'
import { authOptions } from './auth/[...nextauth]'
import { supabaseAdmin } from '@/lib/supabase'

// ── Gemma 4 호출 ─────────────────────────────────
async function callGemma(systemPrompt: string, userPrompt: string, imageBase64?: string) {
  const parts: any[] = []
  if (imageBase64) {
    parts.push({ inlineData: { mimeType: 'image/jpeg', data: imageBase64 } })
  }
  parts.push({ text: userPrompt })

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemma-4-27b-it:generateContent?key=${process.env.GEMMA_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: { maxOutputTokens: 1024, temperature: 0.92 },
      }),
    }
  )
  const data = await response.json()
  return data.candidates?.[0]?.content?.parts?.[0]?.text || ''
}

// ── Claude 폴백 호출 ─────────────────────────────
async function callClaude(systemPrompt: string, userPrompt: string, imageBase64?: string) {
  const content: any[] = []
  if (imageBase64) {
    content.push({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: imageBase64 } })
  }
  content.push({ type: 'text', text: userPrompt })

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.CLAUDE_API_KEY!,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-5',
      max_tokens: 1024,
      system: systemPrompt,
      messages: [{ role: 'user', content }],
    }),
  })
  const data = await response.json()
  return data.content?.map((b: any) => b.text || '').join('') || ''
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const session = await getServerSession(req, res, authOptions)
  if (!session?.user?.id) {
    return res.status(401).json({ error: '로그인이 필요합니다' })
  }

  // 사용량 제한 확인
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('plan, essay_count, count_reset_at')
    .eq('id', session.user.id)
    .single()

  const FREE_LIMIT = Number(process.env.FREE_PLAN_LIMIT || 10)
  if (user?.plan === 'free' && user.essay_count >= FREE_LIMIT) {
    return res.status(403).json({
      error: `무료 플랜은 월 ${FREE_LIMIT}편 제한입니다. Pro로 업그레이드하세요.`,
      code: 'PLAN_LIMIT_EXCEEDED',
    })
  }

  const { systemPrompt, userPrompt, imageBase64 } = req.body

  if (!userPrompt) return res.status(400).json({ error: '프롬프트가 없습니다' })

  try {
    // ① Gemma 4 시도
    let text = ''
    let engine = ''
    try {
      text = await callGemma(systemPrompt, userPrompt, imageBase64)
      engine = 'Gemma 4'
    } catch (e) {
      // ② Claude 폴백
      text = await callClaude(systemPrompt, userPrompt, imageBase64)
      engine = 'Claude'
    }

    if (!text) return res.status(500).json({ error: 'AI 응답이 없습니다' })

    return res.status(200).json({ text, engine })
  } catch (err: any) {
    return res.status(500).json({ error: err.message })
  }
}

// 큰 이미지 허용
export const config = {
  api: { bodyParser: { sizeLimit: '10mb' } },
}
