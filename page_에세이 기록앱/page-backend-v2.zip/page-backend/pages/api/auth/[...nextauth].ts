import NextAuth, { NextAuthOptions } from 'next-auth'
import GoogleProvider from 'next-auth/providers/google'
import FacebookProvider from 'next-auth/providers/facebook'
import { supabaseAdmin } from '@/lib/supabase'

// ── 카카오 커스텀 Provider ────────────────────────
const KakaoProvider = {
  id: 'kakao',
  name: '카카오',
  type: 'oauth' as const,
  authorization: {
    url: 'https://kauth.kakao.com/oauth/authorize',
    params: { scope: 'profile_nickname profile_image account_email' }
  },
  token: 'https://kauth.kakao.com/oauth/token',
  userinfo: 'https://kapi.kakao.com/v2/user/me',
  clientId: process.env.KAKAO_CLIENT_ID,
  clientSecret: process.env.KAKAO_CLIENT_SECRET || 'none',
  profile(profile: any) {
    return {
      id:    String(profile.id),
      name:  profile.kakao_account?.profile?.nickname || '카카오유저',
      email: profile.kakao_account?.email || `kakao_${profile.id}@page.ai`,
      image: profile.kakao_account?.profile?.profile_image_url || null,
    }
  }
}

// ── NextAuth 옵션 ─────────────────────────────────
export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId:     process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    FacebookProvider({
      clientId:     process.env.FACEBOOK_CLIENT_ID!,
      clientSecret: process.env.FACEBOOK_CLIENT_SECRET!,
    }),
    KakaoProvider as any,
  ],

  callbacks: {
    // ── 로그인 콜백 — Supabase에 유저 저장 ──────────
    async signIn({ user, account, profile }) {
      if (!account || !user.email) return false

      try {
        const { data: existing } = await supabaseAdmin
          .from('users')
          .select('id, plan')
          .eq('provider', account.provider)
          .eq('provider_id', account.providerAccountId)
          .single()

        if (existing) {
          // 기존 유저 — 마지막 로그인 시간 갱신
          await supabaseAdmin
            .from('users')
            .update({ last_login: new Date().toISOString() })
            .eq('id', existing.id)
        } else {
          // 신규 유저 — 회원가입 처리
          const { error } = await supabaseAdmin.from('users').insert({
            email: user.email,
            name: user.name || '익명',
            avatar_url: user.image || '',
            provider: account.provider,
            provider_id: account.providerAccountId,
            plan: 'free',
            essay_count: 0,
          })
          if (error) {
            console.error('신규 유저 생성 오류:', error)
            return false
          }
        }
        return true
      } catch (err) {
        console.error('signIn 콜백 오류:', err)
        return false
      }
    },

    // ── JWT 콜백 — 토큰에 유저 정보 추가 ───────────
    async jwt({ token, account, profile }) {
      if (account) {
        // 최초 로그인 시 DB에서 유저 정보 조회
        const { data: dbUser } = await supabaseAdmin
          .from('users')
          .select('id, plan, essay_count')
          .eq('provider', account.provider)
          .eq('provider_id', account.providerAccountId)
          .single()

        if (dbUser) {
          token.userId   = dbUser.id
          token.plan     = dbUser.plan
          token.provider = account.provider
        }
      }
      return token
    },

    // ── 세션 콜백 — 클라이언트에 세션 정보 제공 ────
    async session({ session, token }) {
      session.user.id       = token.userId as string
      session.user.plan     = token.plan as string
      session.user.provider = token.provider as string
      return session
    },
  },

  pages: {
    signIn: '/auth/login',   // 커스텀 로그인 페이지
    error: '/auth/error',
  },

  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30일
  },

  secret: process.env.NEXTAUTH_SECRET,
}

export default NextAuth(authOptions)
