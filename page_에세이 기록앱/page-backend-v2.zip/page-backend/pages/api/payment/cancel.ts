import type { NextApiRequest, NextApiResponse } from 'next'
import { withAuth } from '@/middleware/auth'
import { supabaseAdmin } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  return withAuth(req, res, async (req, res, userId) => {
    // 활성 구독 조회
    const { data: sub } = await supabaseAdmin
      .from('subscriptions')
      .select('id, toss_payment_key, amount, plan')
      .eq('user_id', userId)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(1)
      .single()

    if (!sub) {
      return res.status(404).json({ error: '활성 구독이 없습니다' })
    }

    const { reason = '고객 요청' } = req.body

    try {
      // 토스 환불 API 호출
      const tossResp = await fetch(
        `https://api.tosspayments.com/v1/payments/${sub.toss_payment_key}/cancel`,
        {
          method: 'POST',
          headers: {
            Authorization: `Basic ${Buffer.from(process.env.TOSS_SECRET_KEY + ':').toString('base64')}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ cancelReason: reason }),
        }
      )

      if (!tossResp.ok) {
        const err = await tossResp.json()
        return res.status(400).json({ error: err.message || '환불 처리 실패' })
      }

      // DB 구독 상태 변경
      await supabaseAdmin
        .from('subscriptions')
        .update({ status: 'cancelled', cancelled_at: new Date().toISOString() })
        .eq('id', sub.id)

      // 유저 플랜 초기화
      await supabaseAdmin
        .from('users')
        .update({ plan: 'free' })
        .eq('id', userId)

      return res.status(200).json({
        success: true,
        message: '구독이 해지되었습니다. 당월 말까지는 서비스를 이용할 수 있습니다.',
      })
    } catch (err: any) {
      return res.status(500).json({ error: err.message })
    }
  })
}
