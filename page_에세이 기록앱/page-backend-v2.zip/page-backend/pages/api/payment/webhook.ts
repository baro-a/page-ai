import type { NextApiRequest, NextApiResponse } from 'next'
import { supabaseAdmin } from '@/lib/supabase'
import crypto from 'crypto'

// Webhook 서명 검증
function verifyTossWebhook(body: string, signature: string): boolean {
  const secret = process.env.TOSS_WEBHOOK_SECRET || ''
  const hmac   = crypto.createHmac('sha256', secret).update(body).digest('base64')
  return hmac === signature
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  // 서명 검증 (위변조 방지)
  const signature = req.headers['toss-signature'] as string
  const rawBody   = JSON.stringify(req.body)

  if (process.env.NODE_ENV === 'production' && !verifyTossWebhook(rawBody, signature)) {
    console.error('Webhook 서명 검증 실패')
    return res.status(401).json({ error: '서명 검증 실패' })
  }

  const { eventType, data } = req.body

  try {
    switch (eventType) {
      // 결제 완료 (confirm API가 처리하지 못한 경우 보완)
      case 'PAYMENT_STATUS_CHANGED':
        if (data.status === 'DONE') {
          await supabaseAdmin.from('payment_logs').insert({
            event_type:   'webhook_payment_done',
            order_id:     data.orderId,
            payment_key:  data.paymentKey,
            amount:       data.totalAmount,
            raw_response: data,
          })
        }
        break

      // 취소/환불
      case 'PAYMENT_CANCEL':
        await supabaseAdmin
          .from('subscriptions')
          .update({
            status:       'cancelled',
            cancelled_at: new Date().toISOString(),
          })
          .eq('toss_order_id', data.orderId)

        // 유저 플랜 초기화
        const { data: sub } = await supabaseAdmin
          .from('subscriptions')
          .select('user_id')
          .eq('toss_order_id', data.orderId)
          .single()

        if (sub) {
          await supabaseAdmin
            .from('users')
            .update({ plan: 'free' })
            .eq('id', sub.user_id)
        }

        await supabaseAdmin.from('payment_logs').insert({
          event_type:   'webhook_cancel',
          order_id:     data.orderId,
          raw_response: data,
        })
        break
    }

    return res.status(200).json({ received: true })
  } catch (err) {
    console.error('Webhook 처리 오류:', err)
    return res.status(500).json({ error: 'Webhook 처리 실패' })
  }
}

// Webhook은 raw body 필요
export const config = {
  api: { bodyParser: true },
}
