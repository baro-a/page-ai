import type { NextApiRequest, NextApiResponse } from 'next'
import { getServerSession } from 'next-auth'
import { authOptions } from '../auth/[...nextauth]'
import { supabaseAdmin } from '@/lib/supabase'

// ── 요금제 정보 ───────────────────────────────────
const PLANS: Record<string, { amount: number; expireDays: number; name: string }> = {
  pro:     { amount: 9900,  expireDays: 30, name: 'Pro'     },
  premium: { amount: 19900, expireDays: 30, name: 'Premium' },
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  // ── 1. 로그인 확인 ─────────────────────────────
  const session = await getServerSession(req, res, authOptions)
  if (!session?.user?.id) {
    return res.status(401).json({ error: '로그인이 필요합니다' })
  }

  const { paymentKey, orderId, amount, plan } = req.body

  // ── 2. 필수값 검증 ─────────────────────────────
  if (!paymentKey || !orderId || !amount || !plan) {
    return res.status(400).json({ error: '결제 정보가 누락되었습니다' })
  }

  const planInfo = PLANS[plan]
  if (!planInfo) {
    return res.status(400).json({ error: '유효하지 않은 요금제입니다' })
  }

  // ── 3. 금액 위변조 방지 검증 ──────────────────
  // 클라이언트가 보낸 금액 != 실제 요금제 금액이면 거부
  if (Number(amount) !== planInfo.amount) {
    console.error(`금액 불일치: 요청=${amount}, 실제=${planInfo.amount}`)
    return res.status(400).json({ error: '결제 금액이 올바르지 않습니다' })
  }

  try {
    // ── 4. 토스페이먼츠 서버에서 결제 최종 승인 ──
    // 이 단계가 가장 중요: 반드시 백엔드에서 토스 API 호출
    const tossResponse = await fetch('https://api.tosspayments.com/v1/payments/confirm', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${Buffer.from(process.env.TOSS_SECRET_KEY + ':').toString('base64')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ paymentKey, orderId, amount }),
    })

    const tossData = await tossResponse.json()

    if (!tossResponse.ok) {
      console.error('토스 결제 승인 실패:', tossData)
      return res.status(400).json({
        error: tossData.message || '결제 승인에 실패했습니다',
        code: tossData.code,
      })
    }

    // ── 5. 결제 성공 — DB 저장 ────────────────────
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + planInfo.expireDays)

    // 기존 구독 비활성화
    await supabaseAdmin
      .from('subscriptions')
      .update({ status: 'cancelled', cancelled_at: new Date().toISOString() })
      .eq('user_id', session.user.id)
      .eq('status', 'active')

    // 새 구독 생성
    const { error: subError } = await supabaseAdmin.from('subscriptions').insert({
      user_id: session.user.id,
      plan,
      status: 'active',
      amount: planInfo.amount,
      payment_method: tossData.method,
      toss_order_id: orderId,
      toss_payment_key: paymentKey,
      started_at: new Date().toISOString(),
      expires_at: expiresAt.toISOString(),
    })

    if (subError) throw subError

    // 유저 플랜 업그레이드
    await supabaseAdmin
      .from('users')
      .update({ plan })
      .eq('id', session.user.id)

    // 결제 로그 저장
    await supabaseAdmin.from('payment_logs').insert({
      user_id: session.user.id,
      event_type: 'payment_success',
      order_id: orderId,
      payment_key: paymentKey,
      amount: planInfo.amount,
      plan,
      raw_response: tossData,
    })

    return res.status(200).json({
      success: true,
      message: `${planInfo.name} 플랜 업그레이드 완료!`,
      expiresAt: expiresAt.toISOString(),
    })

  } catch (err: any) {
    console.error('결제 처리 오류:', err)
    return res.status(500).json({ error: '서버 오류가 발생했습니다' })
  }
}
