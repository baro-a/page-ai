import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'

export default function PaymentSuccess() {
  const router = useRouter()
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading')
  const [message, setMessage] = useState('')

  useEffect(() => {
    const { paymentKey, orderId, amount } = router.query
    if (!paymentKey || !orderId || !amount) return

    // 백엔드 결제 최종 확인 API 호출
    const plan = orderId.toString().includes('premium') ? 'premium' : 'pro'

    fetch('/api/payment/confirm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentKey, orderId, amount: Number(amount), plan }),
    })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setStatus('success')
          setMessage(data.message || '결제가 완료되었습니다!')
          // 3초 후 앱으로 이동
          setTimeout(() => router.push('/'), 3000)
        } else {
          setStatus('error')
          setMessage(data.error || '결제 확인에 실패했습니다')
        }
      })
      .catch(() => {
        setStatus('error')
        setMessage('서버 연결에 실패했습니다')
      })
  }, [router.query])

  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0D0702, #1A0E06)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: "'Manrope', sans-serif",
    },
    card: {
      background: 'linear-gradient(145deg, #130a04, #1e0f06)',
      border: '1px solid rgba(200,168,74,0.2)',
      borderRadius: 28, padding: '48px 40px',
      textAlign: 'center' as const, maxWidth: 400, width: '100%',
    },
    icon: { fontSize: 64, marginBottom: 20 },
    title: {
      fontFamily: "'Newsreader', serif", fontStyle: 'italic',
      fontSize: 26, color: 'rgba(245,237,216,0.95)', marginBottom: 12,
    },
    message: { fontSize: 14, color: 'rgba(200,168,74,0.6)', lineHeight: 1.7 },
    btn: {
      marginTop: 28, padding: '14px 32px', borderRadius: 100,
      background: 'linear-gradient(135deg, #C8A84A, #8B6520)',
      color: '#0A0400', border: 'none', fontWeight: 800,
      fontSize: 12, letterSpacing: '0.1em', cursor: 'pointer',
      textTransform: 'uppercase' as const,
    },
  }

  return (
    <>
      <Head><title>결제 완료 — Page</title></Head>
      <div style={styles.container}>
        <div style={styles.card}>
          {status === 'loading' && (
            <>
              <div style={styles.icon}>⏳</div>
              <div style={styles.title}>결제 확인 중</div>
              <div style={styles.message}>잠시만 기다려주세요...</div>
            </>
          )}
          {status === 'success' && (
            <>
              <div style={styles.icon}>🎉</div>
              <div style={styles.title}>결제 완료!</div>
              <div style={styles.message}>{message}<br/>3초 후 앱으로 이동합니다</div>
              <button style={styles.btn} onClick={() => router.push('/')}>앱으로 이동</button>
            </>
          )}
          {status === 'error' && (
            <>
              <div style={styles.icon}>❌</div>
              <div style={styles.title}>결제 오류</div>
              <div style={styles.message}>{message}</div>
              <button style={styles.btn} onClick={() => router.push('/')}>돌아가기</button>
            </>
          )}
        </div>
      </div>
    </>
  )
}
