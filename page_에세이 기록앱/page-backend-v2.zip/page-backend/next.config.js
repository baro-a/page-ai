/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,

  // CORS 헤더 설정 (프론트엔드 HTML이 다른 도메인에서 호출 시)
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Credentials', value: 'true' },
          { key: 'Access-Control-Allow-Origin', value: process.env.NEXT_PUBLIC_APP_URL || '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET,POST,PUT,DELETE,OPTIONS' },
          { key: 'Access-Control-Allow-Headers', value: 'Content-Type,Authorization' },
        ],
      },
    ]
  },

  // 큰 이미지 base64 허용
  api: {
    bodyParser: {
      sizeLimit: '10mb',
    },
  },

  // 이미지 도메인 허용
  images: {
    domains: [
      'lh3.googleusercontent.com',   // 구글 프로필
      'graph.facebook.com',           // 페이스북 프로필
      'k.kakaocdn.net',               // 카카오 프로필
      'ssl.pstatic.net',              // 네이버 프로필
    ],
  },
}

module.exports = nextConfig
