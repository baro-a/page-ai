# 📱 Page.ai 앱 출시 가이드

---

## ✅ 완성된 파일 구조

```
page-app/
├── index.html          ← 메인 앱 (PWA)
├── manifest.json       ← 앱 매니페스트 (이름, 아이콘, 테마)
├── sw.js               ← 서비스 워커 (오프라인 지원)
└── icons/
    ├── icon-72.png
    ├── icon-96.png
    ├── icon-128.png
    ├── icon-144.png
    ├── icon-152.png
    ├── icon-192.png   ← 안드로이드 기본
    ├── icon-384.png
    └── icon-512.png   ← Play Store / 스플래시
```

---

## 🚀 배포 순서

### STEP 1: 웹 호스팅 설정 (필수)

앱 출시 전에 반드시 **HTTPS 도메인**이 필요합니다.

**추천 옵션:**
| 서비스 | 가격 | 특징 |
|--------|------|------|
| **Vercel** | 무료 | GitHub 연동, 자동 배포 |
| **Netlify** | 무료 | 드래그앤드롭 배포 |
| **Firebase Hosting** | 무료 | Google 생태계 |

**Vercel 배포 (가장 빠름):**
1. [vercel.com](https://vercel.com) 가입
2. "New Project" → 폴더 업로드
3. 자동으로 `https://page-app.vercel.app` 생성

---

### STEP 2: Google AdSense 연결

1. **AdSense 가입:** [adsense.google.com](https://adsense.google.com)
2. 사이트 URL 등록 (배포한 도메인 입력)
3. **승인 받기** (보통 1-2주, 최소 콘텐츠 필요)
4. 승인 후 Publisher ID 확인 (`ca-pub-XXXXXXXXXX`)
5. `index.html`에서 **두 군데** 교체:
   ```html
   <!-- 헤더 스크립트 -->
   data-ad-client="ca-pub-YOUR_ID"
   
   <!-- 광고 슬롯 -->
   data-ad-client="ca-pub-YOUR_ID"
   data-ad-slot="YOUR_SLOT_ID"
   ```

> ⚠️ **중요:** AdSense는 콘텐츠 사이트용입니다. 앱스토어 앱에는 **Google AdMob**을 사용합니다.
> PWA(웹앱)은 AdSense 사용 가능합니다.

---

### STEP 3: 구글 플레이 스토어 출시

**방법: TWA (Trusted Web Activity)** - 웹앱을 안드로이드 앱으로 변환

#### 3-1. 개발자 계정
- [play.google.com/console](https://play.google.com/console) 가입
- 등록비: **$25 (1회)**

#### 3-2. TWA 생성 (Android Studio 불필요!)

**Bubblewrap CLI 사용:**
```bash
npm i -g @bubblewrap/cli
bubblewrap init --manifest https://your-domain.com/manifest.json
bubblewrap build
```

또는 [PWABuilder.com](https://pwabuilder.com) 이용:
1. 사이트 URL 입력
2. "Build My PWA" 클릭
3. Android 패키지 다운로드 (.aab 파일)

#### 3-3. 스토어 등록 정보

| 항목 | 내용 |
|------|------|
| **앱 이름** | Page — 당신의 인생 도서관 |
| **카테고리** | 생산성 / 라이프스타일 |
| **콘텐츠 등급** | 전체 이용가 |
| **개인정보처리방침** | 필수 (아래 참고) |
| **스크린샷** | 폰 화면 최소 2장 |
| **기능 그래픽** | 1024×500px 배너 |

#### 3-4. 심사 기간
- **구글 플레이:** 보통 1-3일
- **앱스토어:** 보통 1-7일

---

### STEP 4: 애플 앱스토어 출시

**방법: WKWebView 래퍼 앱** (Capacitor 사용)

#### 4-1. 개발자 계정
- [developer.apple.com](https://developer.apple.com) 가입
- 연간 비용: **$99/년**

#### 4-2. Capacitor로 래핑
```bash
npm install @capacitor/core @capacitor/cli @capacitor/ios
npx cap init "Page" "ai.page.app"
npx cap add ios
npx cap open ios
```

> 💡 Mac + Xcode 필요. 없다면 PWABuilder 또는 **Expo** 고려.

---

## 💰 수익화 전략

### AdSense (웹/PWA)
- **배너 광고:** 앱 하단 (이미 코드 삽입됨)
- **기사 광고:** 에세이 목록 사이
- **예상 수익:** 월 방문자 1만명 기준 ₩5-30만

### AdMob (네이티브 앱)
- **전면 광고:** 에세이 생성 전후
- **보상형 광고:** 추가 생성 횟수 제공
- **네이티브 광고:** 서재 목록 사이
- **예상 수익:** 월 활성 1,000명 기준 ₩10-50만

### 인앱 결제 (추천)
- **프리미엄:** ₩9,900/월 (광고 제거 + 무제한)
- **Pro:** ₩19,900/월 (API 접근)
- 구글 플레이/앱스토어 30% 수수료 주의

---

## 📋 필수 준비 서류

### 개인정보처리방침 (Privacy Policy)
앱스토어 심사 **필수**. 아래 내용 포함:
- 수집 정보: 사진(처리 후 미저장), API 호출 로그
- 제3자 제공: Anthropic API, Google AdSense
- 데이터 보관 기간
- 삭제 요청 방법

### 이용약관 (Terms of Service)
- AI 생성 콘텐츠 저작권 안내
- 성인 콘텐츠 금지 조항
- 서비스 변경/종료 조항

---

## 🔑 API 키 보안 주의사항

현재 `index.html`에 Anthropic API 키가 노출되어 있습니다.
**출시 전 반드시 백엔드 서버로 이동하세요:**

```
사용자 → 백엔드 서버 → Anthropic API
              ↑
        API 키 안전 보관
```

**추천 백엔드:** Vercel Edge Functions, Cloudflare Workers, Firebase Functions

---

## 📞 다음 단계 체크리스트

- [ ] 도메인 구매 (예: page.ai, pageapp.kr)
- [ ] Vercel/Netlify 배포
- [ ] Google AdSense 신청 (승인 대기)
- [ ] Anthropic API 키 백엔드 이전
- [ ] 개인정보처리방침 페이지 작성
- [ ] Google Play Console 개발자 등록 ($25)
- [ ] PWABuilder로 APK/AAB 생성
- [ ] 플레이스토어 심사 제출
- [ ] (선택) Apple Developer 등록 ($99/년)
- [ ] Google AdSense Publisher ID 코드에 삽입
