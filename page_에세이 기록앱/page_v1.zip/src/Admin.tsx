import React, { useEffect, useState } from 'react';
import { useAuth } from './AuthContext';

interface UserData {
  uid: string;
  email: string;
  displayName: string;
  plan: string;
  role: string;
  createdAt: string;
}

interface EssayData {
  id: string;
  title: string;
  authorId: string;
  category: string;
  emotion: string;
  createdAt: string;
}

const Admin: React.FC = () => {
  const { profile } = useAuth();
  const [users, setUsers] = useState<UserData[]>([]);
  const [essays, setEssays] = useState<EssayData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (profile?.role !== 'admin') return;
      
      try {
        // Firebase 연동 해제 상태이므로 더미 데이터 제공
        const mockUsers: UserData[] = [
          { uid: 'admin-local-id', email: 'one123@gmail.com', displayName: '관리자', plan: 'pro', role: 'admin', createdAt: new Date().toISOString() },
          { uid: 'user-1', email: 'user1@example.com', displayName: '테스트유저1', plan: 'free', role: 'user', createdAt: new Date().toISOString() },
          { uid: 'user-2', email: 'user2@example.com', displayName: '테스트유저2', plan: 'premium', role: 'user', createdAt: new Date().toISOString() },
        ];
        setUsers(mockUsers);

        const mockEssays: EssayData[] = [
          { id: 'essay-1', title: '나의 첫 에세이', authorId: 'user-1', category: '일상', emotion: '행복', createdAt: new Date().toISOString() },
          { id: 'essay-2', title: '여행의 기록', authorId: 'user-2', category: '여행', emotion: '설렘', createdAt: new Date().toISOString() },
        ];
        setEssays(mockEssays);
      } catch (err) {
        console.error('Failed to fetch admin data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [profile]);

  if (profile?.role !== 'admin') {
    return <div className="p-8 text-center text-red-500">접근 권한이 없습니다.</div>;
  }

  if (loading) {
    return <div className="p-8 text-center text-amber-500">데이터를 불러오는 중...</div>;
  }

  const premiumUsers = users.filter(u => u.plan === 'premium').length;
  const proUsers = users.filter(u => u.plan === 'pro').length;
  const totalRevenue = (premiumUsers * 9900) + (proUsers * 19900);

  return (
    <div className="flex min-h-[calc(100vh-80px)] bg-[#FAF5EE] text-[#150A02]">
      {/* Sidebar */}
      <aside className="w-64 bg-[#2C1508] text-[#E0BF9A] p-6 hidden md:flex flex-col gap-2 border-r border-amber-900/20">
        <div className="mb-6">
          <div className="font-serif text-lg text-amber-300">관리자 대시보드</div>
          <div className="text-xs text-amber-500/50 mt-1">Page.ai</div>
        </div>
        
        <button className="flex items-center gap-3 p-3 rounded-xl bg-amber-500/10 text-amber-300 font-medium transition-colors text-sm text-left">
          <span>📊</span> 개요
        </button>
        <button className="flex items-center gap-3 p-3 rounded-xl hover:bg-amber-500/10 transition-colors text-sm text-left">
          <span>👥</span> 사용자
        </button>
        <button className="flex items-center gap-3 p-3 rounded-xl hover:bg-amber-500/10 transition-colors text-sm text-left">
          <span>📝</span> 에세이
        </button>
      </aside>

      {/* Main */}
      <main className="flex-1 p-8 overflow-y-auto">
        <h1 className="text-3xl font-bold font-serif text-[#3E2010] mb-8">대시보드 개요</h1>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-white p-6 rounded-2xl border border-[#E0BF9A] shadow-sm">
            <div className="text-xs font-bold text-[#9A5A30] uppercase tracking-wider mb-2">전체 사용자</div>
            <div className="text-3xl font-bold text-[#3E2010]">{users.length}</div>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-[#E0BF9A] shadow-sm">
            <div className="text-xs font-bold text-[#9A5A30] uppercase tracking-wider mb-2">월 구독 매출 (예상)</div>
            <div className="text-3xl font-bold text-[#3E2010]">₩{totalRevenue.toLocaleString()}</div>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-[#E0BF9A] shadow-sm">
            <div className="text-xs font-bold text-[#9A5A30] uppercase tracking-wider mb-2">생성된 에세이</div>
            <div className="text-3xl font-bold text-[#3E2010]">{essays.length}</div>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-[#E0BF9A] shadow-sm">
            <div className="text-xs font-bold text-[#9A5A30] uppercase tracking-wider mb-2">유료 사용자 비율</div>
            <div className="text-3xl font-bold text-[#3E2010]">
              {users.length > 0 ? Math.round(((premiumUsers + proUsers) / users.length) * 100) : 0}%
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Users */}
          <div className="bg-white rounded-2xl border border-[#E0BF9A] shadow-sm overflow-hidden">
            <div className="p-6 border-b border-[#F0DEC8]">
              <h3 className="text-lg font-bold text-[#5C3018]">최근 가입 사용자</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#FAF5EE] text-[#9A5A30]">
                  <tr>
                    <th className="p-4 font-semibold">이름</th>
                    <th className="p-4 font-semibold">이메일</th>
                    <th className="p-4 font-semibold">플랜</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F0DEC8]">
                  {users.slice(0, 5).map(u => (
                    <tr key={u.uid} className="hover:bg-[#FAF5EE]/50">
                      <td className="p-4 font-medium text-[#3E2010]">{u.displayName}</td>
                      <td className="p-4 text-[#7A4220]">{u.email}</td>
                      <td className="p-4">
                        <span className={`px-2.5 py-1 rounded-md text-xs font-bold ${
                          u.plan === 'pro' ? 'bg-blue-100 text-blue-800' :
                          u.plan === 'premium' ? 'bg-green-100 text-green-800' :
                          'bg-stone-100 text-stone-600'
                        }`}>
                          {u.plan.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Recent Essays */}
          <div className="bg-white rounded-2xl border border-[#E0BF9A] shadow-sm overflow-hidden">
            <div className="p-6 border-b border-[#F0DEC8]">
              <h3 className="text-lg font-bold text-[#5C3018]">최근 생성 에세이</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#FAF5EE] text-[#9A5A30]">
                  <tr>
                    <th className="p-4 font-semibold">제목</th>
                    <th className="p-4 font-semibold">카테고리</th>
                    <th className="p-4 font-semibold">감정</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F0DEC8]">
                  {essays.slice(0, 5).map(e => (
                    <tr key={e.id} className="hover:bg-[#FAF5EE]/50">
                      <td className="p-4 font-medium text-[#3E2010] truncate max-w-[200px]">{e.title}</td>
                      <td className="p-4 text-[#7A4220]">{e.category}</td>
                      <td className="p-4 text-[#7A4220]">{e.emotion}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Admin;
