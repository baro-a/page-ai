import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { AuthProvider, useAuth } from './AuthContext';
import { auth } from './firebase';
import Login from './Login';
import Subscription from './Subscription';
import Landing from './Landing';
import Library from './Library';
import CreateEssay from './CreateEssay';
import EssayDetail from './EssayDetail';
import Admin from './Admin';

// 기존 HTML의 UI를 React 컴포넌트로 분리하는 작업은 점진적으로 진행합니다.
// 현재는 라우팅 구조와 인증 컨텍스트를 최상위에 감싸는 뼈대를 구성합니다.

const ProtectedRoute: React.FC<{ children: React.ReactNode, adminOnly?: boolean }> = ({ children, adminOnly }) => {
  const { profile, loading } = useAuth();

  if (loading) return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#0D0702]">
      <div className="w-12 h-12 border-4 border-amber-900/30 border-t-amber-500 rounded-full animate-spin mb-4"></div>
      <div className="text-amber-500 font-serif tracking-widest animate-pulse">페이지를 펼치는 중...</div>
    </div>
  );

  // 로컬 관리자 또는 인증된 유저 체크
  if (!profile) return <Navigate to="/login" />;
  if (adminOnly && profile?.role !== 'admin') return <Navigate to="/" />;

  return <>{children}</>;
};

const AppContent: React.FC = () => {
  const { profile } = useAuth();

  return (
    <div className="min-h-screen bg-[#0D0702] text-[#F5EDD8] font-sans">
      <nav className="fixed top-0 w-full bg-[#140803]/80 backdrop-blur-md border-b border-amber-900/30 z-50 px-6 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-amber-500 tracking-wider font-serif cursor-pointer">Page</Link>
        <div className="flex gap-4 items-center">
          {profile ? (
            <>
              <span className="text-sm text-amber-200/60">{profile?.displayName}님</span>
              {profile?.role === 'admin' && (
                <Link to="/admin" className="text-sm text-amber-500 hover:text-amber-400">관리자</Link>
              )}
              <Link to="/library" className="text-sm text-amber-100/80 hover:text-white">내 서재</Link>
              <Link to="/subscription" className="text-sm text-amber-100/80 hover:text-white">구독관리</Link>
              <button 
                onClick={() => {
                  // 로컬 로그아웃 처리 (새로고침으로 상태 초기화)
                  localStorage.removeItem('page_ai_profile');
                  window.location.href = '/login';
                }} 
                className="text-sm px-4 py-2 rounded-full border border-amber-900/50 hover:bg-amber-900/20 transition-colors"
              >
                로그아웃
              </button>
            </>
          ) : (
            <Link to="/login" className="text-sm px-6 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-900 font-bold rounded-full transition-colors">
              로그인
            </Link>
          )}
        </div>
      </nav>

      <main className="pt-20">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route 
            path="/subscription" 
            element={
              <ProtectedRoute>
                <Subscription />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/library" 
            element={
              <ProtectedRoute>
                <Library />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/create" 
            element={
              <ProtectedRoute>
                <CreateEssay />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/essay/:id" 
            element={
              <ProtectedRoute>
                <EssayDetail />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin" 
            element={
              <ProtectedRoute adminOnly>
                <Admin />
              </ProtectedRoute>
            } 
          />
          <Route path="/" element={<Landing />} />
        </Routes>
      </main>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}
