import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';

interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  role: 'user' | 'admin';
  plan: 'free' | 'premium' | 'pro';
  subscriptionStartDate?: string;
  hardcoverCredits: number;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  setMockAdmin: () => void;
}

const AuthContext = createContext<AuthContextType>({ 
  user: null, 
  profile: null, 
  loading: true,
  setMockAdmin: () => {}
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const setMockAdmin = () => {
    const mockAdmin: UserProfile = {
      uid: 'admin-local-id',
      email: 'one123@gmail.com',
      displayName: '관리자',
      photoURL: '',
      role: 'admin',
      plan: 'pro',
      hardcoverCredits: 999,
      createdAt: new Date().toISOString()
    };
    setProfile(mockAdmin);
    setLoading(false);
    // 로그인 상태 로컬 스토리지 저장
    localStorage.setItem('page_ai_profile', JSON.stringify(mockAdmin));
  };

  useEffect(() => {
    // 로컬 스토리지에서 프로필 복구 시도
    const savedProfile = localStorage.getItem('page_ai_profile');
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile));
      setLoading(false);
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (!savedProfile) {
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ user, profile, loading, setMockAdmin }}>
      {children}
    </AuthContext.Provider>
  );
};
