import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from './firebase';

interface Essay {
  id: string;
  title: string;
  body: string;
  emotion: string;
  category: string;
  date: string;
  image?: string;
  imgType?: string;
}

const Library: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [essays, setEssays] = useState<Essay[]>([]);
  const [loading, setLoading] = useState(true);

  const categories = [
    { emoji: '📔', name: '일상', count: 0 },
    { emoji: '🧳', name: '여행', count: 0 },
    { emoji: '🏠', name: '가족', count: 0 },
    { emoji: '💼', name: '업무', count: 0 },
    { emoji: '🎁', name: '특별한 날', count: 0 },
    { emoji: '🍽️', name: '맛집', count: 0 },
  ];

  useEffect(() => {
    const fetchEssays = async () => {
      if (!profile) return;
      try {
        // 로컬 스토리지에서 에세이 목록 불러오기
        const savedEssays = localStorage.getItem(`essays_${profile.uid}`);
        if (savedEssays) {
          setEssays(JSON.parse(savedEssays));
        } else {
          setEssays([]);
        }
      } catch (err) {
        console.error('Failed to fetch essays:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchEssays();
  }, [profile]);

  return (
    <div className="flex min-h-[calc(100vh-80px)] bg-[#FAF5EE] text-[#150A02]">
      {/* Sidebar */}
      <aside className="w-64 bg-[#2C1508] text-[#E0BF9A] p-6 hidden md:flex flex-col gap-2 border-r border-amber-900/20">
        <div className="mb-6">
          <div className="font-serif text-lg text-amber-300">나의 서재</div>
          <div className="text-xs text-amber-500/50 mt-1">{profile?.displayName}님의 인생 도서관</div>
        </div>
        
        <div className="text-[10px] tracking-widest uppercase text-amber-500/40 font-bold mt-4 mb-2">탐색</div>
        <button className="flex items-center gap-3 p-3 rounded-xl bg-amber-500/10 text-amber-300 font-medium transition-colors text-sm text-left">
          <span>📚</span> 전체 서재
          <span className="ml-auto bg-amber-500/20 text-amber-400 text-[10px] px-2 py-0.5 rounded-md">{essays.length}</span>
        </button>
        <button onClick={() => navigate('/create')} className="flex items-center gap-3 p-3 rounded-xl hover:bg-amber-500/10 transition-colors text-sm text-left">
          <span>✦</span> 새 에세이 쓰기
        </button>

        <div className="text-[10px] tracking-widest uppercase text-amber-500/40 font-bold mt-6 mb-2">책장</div>
        {categories.map((cat, idx) => (
          <button key={idx} className="flex items-center gap-3 p-3 rounded-xl hover:bg-amber-500/10 transition-colors text-sm text-left">
            <span>{cat.emoji}</span> {cat.name}
          </button>
        ))}
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold font-serif text-[#3E2010]">나의 서재</h1>
            <p className="text-sm text-[#9A5A30] mt-1">{essays.length}편의 이야기</p>
          </div>
          <div className="flex gap-3">
            <button className="px-4 py-2 rounded-full border border-[#E0BF9A] text-[#7A4220] text-sm font-medium hover:bg-[#F0DEC8] transition-colors">
              🔍 검색
            </button>
            <button 
              onClick={() => navigate('/create')}
              className="px-5 py-2 rounded-full bg-gradient-to-r from-[#C8A84A] to-[#A88030] text-[#1A0C05] text-sm font-bold shadow-lg hover:scale-105 transition-transform"
            >
              ✦ 새 에세이 쓰기
            </button>
          </div>
        </div>

        {/* Bookshelf Visual */}
        <div className="bg-gradient-to-b from-[#3E2010] to-[#2C1508] rounded-2xl p-8 shadow-inner mb-12">
          <div className="flex gap-4 flex-wrap pb-4 border-b-8 border-black/40 relative">
            {categories.map((cat, idx) => (
              <div key={idx} className="w-24 h-36 rounded-r-md rounded-l-sm bg-gradient-to-br from-[#7B3A18] to-[#4A2C10] shadow-lg flex flex-col justify-between p-3 cursor-pointer hover:-translate-y-2 transition-transform border-l-4 border-black/30 relative overflow-hidden">
                <div className="absolute top-4 left-2 right-2 h-px bg-amber-500/30"></div>
                <div className="absolute bottom-4 left-2 right-2 h-px bg-amber-500/30"></div>
                <div className="text-2xl drop-shadow-md">{cat.emoji}</div>
                <div>
                  <div className="text-xs font-bold text-[#E8C890] leading-tight">{cat.name}</div>
                </div>
              </div>
            ))}
            <div 
              className="w-24 h-36 rounded-md border-2 border-dashed border-amber-500/30 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-amber-500/10 transition-colors text-amber-500/50"
            >
              <span className="text-2xl">+</span>
              <span className="text-[10px]">책장 추가</span>
            </div>
            <div className="absolute -bottom-2 left-0 right-0 h-1.5 bg-gradient-to-b from-[#783C14] to-[#50280A] rounded-sm"></div>
          </div>
        </div>

        {/* Recent Essays */}
        <div>
          <h2 className="text-xl font-bold text-[#5C3018] mb-6 font-serif">최근 에세이</h2>
          
          {loading ? (
            <div className="text-center py-12 text-[#9A5A30]">이야기를 불러오는 중...</div>
          ) : essays.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border border-[#F0DEC8]">
              <div className="text-4xl mb-4">📖</div>
              <h3 className="text-lg font-bold text-[#5C3018] mb-2">아직 저장된 에세이가 없습니다</h3>
              <p className="text-sm text-[#9A5A30] mb-6">사진을 업로드하고 AI 에세이를 생성해보세요</p>
              <button 
                onClick={() => navigate('/create')}
                className="px-6 py-3 bg-[#C8A84A] text-[#1A0C05] font-bold rounded-full shadow-md hover:bg-[#D4B060] transition-colors"
              >
                ✦ 첫 에세이 쓰기
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {essays.map((essay) => (
                <div key={essay.id} onClick={() => navigate(`/essay/${essay.id}`)} className="bg-white rounded-xl overflow-hidden border border-[#F0DEC8] hover:-translate-y-1 hover:shadow-xl transition-all cursor-pointer group">
                  <div className="h-32 bg-[#F0DEC8] flex items-center justify-center overflow-hidden">
                    {essay.image ? (
                      <img src={essay.image} alt={essay.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    ) : (
                      <span className="text-4xl">📝</span>
                    )}
                  </div>
                  <div className="p-4">
                    <div className="inline-block px-3 py-1 bg-[#FEF3E2] text-[#8B5E2A] text-[10px] font-bold rounded-full mb-3">
                      {essay.emotion}
                    </div>
                    <h3 className="font-bold text-[#3E2010] text-sm mb-2 line-clamp-1">{essay.title}</h3>
                    <p className="text-xs text-[#9A5A30] line-clamp-2 leading-relaxed mb-4">
                      {essay.body}
                    </p>
                    <div className="flex justify-between items-center pt-3 border-t border-[#F0DEC8]">
                      <span className="text-[10px] text-[#C0845A]">{essay.date}</span>
                      <span className="text-[10px] px-2 py-1 bg-[#FAF5EE] text-[#9A5A30] rounded-md">{essay.category}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Library;
