import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { collection, addDoc } from 'firebase/firestore';
import { db } from './firebase';
import { GoogleGenAI } from '@google/genai';

const CreateEssay: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [photo, setPhoto] = useState<string | null>(null);
  const [emotion, setEmotion] = useState('행복');
  const [context, setContext] = useState('');
  const [category, setCategory] = useState('일상');
  const [style, setStyle] = useState('감성적 일상체');
  const [format, setFormat] = useState('일상 에세이');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    const currentUid = profile?.uid;
    if (!currentUid) return;
    setLoading(true);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const prompt = `다음 정보를 바탕으로 ${format}를 한국어로 작성해주세요.
감정: ${emotion}
카테고리: ${category}
글쓰기 스타일: ${style}
${context ? '추가 상황: ' + context : ''}

사진을 분석하여 그 장면과 분위기를 글에 자연스럽게 녹여주세요.
제목(한 줄) 먼저 쓰고 빈 줄 후 본문을 써주세요.`;

      let responseText = '';

      if (photo) {
        const base64Data = photo.split(',')[1];
        const mimeType = photo.split(';')[0].split(':')[1];
        
        const response = await ai.models.generateContent({
          model: 'gemini-2.0-flash',
          contents: [
            {
              role: 'user',
              parts: [
                { inlineData: { data: base64Data, mimeType } },
                { text: prompt }
              ]
            }
          ]
        });
        responseText = response.text || '';
      } else {
        const response = await ai.models.generateContent({
          model: 'gemini-2.0-flash',
          contents: prompt
        });
        responseText = response.text || '';
      }

      const lines = responseText.split('\n').filter(l => l.trim());
      const title = lines[0]?.replace(/^제목:\s*/, '') || '오늘의 에세이';
      const body = lines.slice(1).join('\n').trim();

      const newEssay = {
        id: Date.now().toString(),
        authorId: currentUid,
        title,
        body,
        emotion,
        category,
        format,
        image: photo,
        imgType: photo ? photo.split(';')[0].split(':')[1] : null,
        date: new Date().toLocaleDateString('ko-KR', { month: 'long', day: 'numeric' }),
        dateISO: new Date().toISOString(),
        isPublic: false,
        createdAt: new Date().toISOString()
      };

      // 로컬 스토리지에 저장
      const savedEssays = localStorage.getItem(`essays_${currentUid}`);
      const essays = savedEssays ? JSON.parse(savedEssays) : [];
      essays.unshift(newEssay);
      localStorage.setItem(`essays_${currentUid}`, JSON.stringify(essays));

      navigate('/library');

    } catch (err) {
      console.error('Generation failed:', err);
      alert('에세이 생성 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-6 text-stone-200">
      <h2 className="text-3xl font-bold mb-2 text-amber-500 font-serif">새 에세이 쓰기</h2>
      <p className="text-stone-400 mb-8">오늘의 순간을 기록해보세요</p>

      {/* Step Indicator */}
      <div className="flex gap-2 mb-8 bg-stone-800 p-2 rounded-xl border border-stone-700">
        {[1, 2, 3, 4].map(num => (
          <div 
            key={num} 
            className={`flex-1 text-center py-2 rounded-lg text-sm font-bold transition-colors ${
              step === num ? 'bg-amber-600 text-stone-900' : 
              step > num ? 'text-amber-500' : 'text-stone-500'
            }`}
          >
            {num}단계
          </div>
        ))}
      </div>

      {/* Step 1: Photo */}
      {step === 1 && (
        <div className="bg-stone-800 p-8 rounded-2xl border border-stone-700">
          <h3 className="text-xl font-bold mb-2 text-stone-200">📷 사진 업로드</h3>
          <p className="text-sm text-stone-400 mb-6">사진이 있어야 에세이 작성이 시작됩니다.</p>
          
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-amber-500/30 rounded-xl p-12 text-center cursor-pointer hover:bg-amber-500/5 transition-colors"
          >
            {photo ? (
              <img src={photo} alt="Preview" className="max-h-64 mx-auto rounded-lg" />
            ) : (
              <div>
                <div className="text-4xl mb-4">🖼️</div>
                <div className="text-stone-300 font-bold mb-2">사진을 클릭해서 업로드하세요</div>
                <div className="text-xs text-stone-500">JPG · PNG 지원</div>
              </div>
            )}
          </div>
          <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />

          <div className="mt-8 flex justify-end">
            <button 
              onClick={() => setStep(2)} 
              disabled={!photo}
              className="px-8 py-3 bg-amber-600 text-stone-900 font-bold rounded-xl disabled:opacity-50"
            >
              다음 단계 →
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Emotion & Context */}
      {step === 2 && (
        <div className="space-y-6">
          <div className="bg-stone-800 p-8 rounded-2xl border border-stone-700">
            <h3 className="text-xl font-bold mb-2 text-stone-200">💭 감정 선택</h3>
            <div className="grid grid-cols-4 gap-4 mt-6">
              {['행복', '사랑', '평온', '설렘', '감사', '그리움', '희망', '우울'].map(emo => (
                <button 
                  key={emo}
                  onClick={() => setEmotion(emo)}
                  className={`p-3 rounded-xl border ${emotion === emo ? 'bg-amber-500/20 border-amber-500 text-amber-400' : 'bg-stone-900 border-stone-700 text-stone-400 hover:border-amber-500/50'}`}
                >
                  {emo}
                </button>
              ))}
            </div>
          </div>
          <div className="bg-stone-800 p-8 rounded-2xl border border-stone-700">
            <h3 className="text-xl font-bold mb-2 text-stone-200">📝 상황 메모</h3>
            <textarea 
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="예: 오랜만에 친구들과 함께한 한강 피크닉."
              className="w-full mt-4 p-4 bg-stone-900 border border-stone-700 rounded-xl text-stone-200 focus:border-amber-500 outline-none min-h-[120px]"
            />
          </div>
          <div className="flex justify-between">
            <button onClick={() => setStep(1)} className="px-8 py-3 border border-stone-600 rounded-xl">← 이전</button>
            <button onClick={() => setStep(3)} className="px-8 py-3 bg-amber-600 text-stone-900 font-bold rounded-xl">다음 →</button>
          </div>
        </div>
      )}

      {/* Step 3: Settings */}
      {step === 3 && (
        <div className="space-y-6">
          <div className="bg-stone-800 p-8 rounded-2xl border border-stone-700">
            <h3 className="text-xl font-bold mb-4 text-stone-200">🗂️ 카테고리</h3>
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full p-4 bg-stone-900 border border-stone-700 rounded-xl text-stone-200 outline-none">
              {['일상', '여행', '가족', '업무', '특별한 날', '맛집'].map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="bg-stone-800 p-8 rounded-2xl border border-stone-700">
            <h3 className="text-xl font-bold mb-4 text-stone-200">✍️ 글쓰기 페르소나</h3>
            <select value={style} onChange={(e) => setStyle(e.target.value)} className="w-full p-4 bg-stone-900 border border-stone-700 rounded-xl text-stone-200 outline-none">
              {['감성적 일상체', '문학적 서정체', '브이로그 스크립트', '자서전 회고체'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="flex justify-between">
            <button onClick={() => setStep(2)} className="px-8 py-3 border border-stone-600 rounded-xl">← 이전</button>
            <button onClick={() => setStep(4)} className="px-8 py-3 bg-amber-600 text-stone-900 font-bold rounded-xl">다음 →</button>
          </div>
        </div>
      )}

      {/* Step 4: Generate */}
      {step === 4 && (
        <div className="bg-stone-800 p-8 rounded-2xl border border-stone-700 text-center">
          <h3 className="text-2xl font-bold mb-6 text-amber-500">✦ AI 에세이 생성</h3>
          <div className="bg-stone-900 p-6 rounded-xl text-left space-y-4 mb-8 border border-stone-700">
            <div className="flex justify-between"><span className="text-stone-400">감정</span><span className="font-bold">{emotion}</span></div>
            <div className="flex justify-between"><span className="text-stone-400">카테고리</span><span className="font-bold">{category}</span></div>
            <div className="flex justify-between"><span className="text-stone-400">스타일</span><span className="font-bold">{style}</span></div>
          </div>
          
          {loading ? (
            <div className="py-12 animate-pulse text-amber-500 font-bold text-xl">
              📖 AI가 당신의 이야기를 쓰고 있습니다...
            </div>
          ) : (
            <div className="flex gap-4 justify-center">
              <button onClick={() => setStep(3)} className="px-8 py-4 border border-stone-600 rounded-xl font-bold">← 이전</button>
              <button onClick={handleGenerate} className="px-10 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-stone-900 font-bold rounded-xl shadow-lg hover:scale-105 transition-transform">
                ✦ 에세이 생성하기
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CreateEssay;
