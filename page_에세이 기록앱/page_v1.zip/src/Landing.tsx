import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';

const Landing: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const flyingBooksRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Flying books animation setup
    if (flyingBooksRef.current && flyingBooksRef.current.children.length === 0) {
      const bookColors = [
        ['#7B3A18','#C8784A'],['#1E4A7A','#5090C8'],['#2A5E2A','#5AAA5A'],
        ['#6A2828','#C85050'],['#4A2E6A','#9060C8'],['#5A3A0A','#C89040'],
        ['#3A4A2A','#7A9060'],['#1A4A4A','#40A0A0'],['#6A1A4A','#C04090'],
        ['#4A3818','#A08050'],['#2A1A5A','#6050B0'],['#5A1A1A','#B04040'],
      ];
      const bookConfigs = [
        {w:36,h:50,sx:'-5vw',sy:'105vh',ex:'25vw',ey:'-20vh',sr:'-15deg',er:'25deg',sc:0.9,dur:14,delay:0,op:0.75,open:false},
        {w:28,h:42,sx:'108vw',sy:'80vh',ex:'70vw',ey:'-15vh',sr:'20deg',er:'-10deg',sc:0.8,dur:18,delay:2.5,op:0.7,open:false},
        {w:44,h:60,sx:'20vw',sy:'108vh',ex:'55vw',ey:'-25vh',sr:'-5deg',er:'30deg',sc:1.1,dur:16,delay:5,op:0.8,open:false},
        {w:70,h:48,sx:'15vw',sy:'110vh',ex:'45vw',ey:'-20vh',sr:'-10deg',er:'5deg',sc:0.9,dur:17,delay:4,op:0.65,open:true},
        {w:80,h:55,sx:'90vw',sy:'108vh',ex:'55vw',ey:'-30vh',sr:'15deg',er:'-8deg',sc:1.0,dur:21,delay:8,op:0.6,open:true},
      ];

      bookConfigs.forEach((cfg, i) => {
        const color = bookColors[i % bookColors.length];
        const el = document.createElement('div');
        el.className = 'fly-book' + (cfg.open ? ' open' : '');
        el.style.cssText = `
          width:${cfg.w}px; height:${cfg.h}px;
          left:${cfg.sx}; top:${cfg.sy};
          --sx:${cfg.sx}; --sy:${cfg.sy};
          --ex:${cfg.ex}; --ey:${cfg.ey};
          --sr:${cfg.sr}; --er:${cfg.er};
          --sc:${cfg.sc}; --op:${cfg.op};
          animation:bookFly ${cfg.dur}s ${cfg.delay}s linear infinite;
        `;
        if (cfg.open) {
          el.innerHTML = `
            <div style="position:absolute;inset:0;display:flex">
              <div style="flex:1;background:linear-gradient(to right,${color[0]},${color[1]});border-radius:4px 0 0 4px;box-shadow:2px 0 8px rgba(0,0,0,0.4)"></div>
              <div style="flex:1;background:linear-gradient(to right,#F0E8D5,#FAF5EC);border-radius:0 4px 4px 0;box-shadow:2px 2px 8px rgba(0,0,0,0.3)">
                <div style="margin:6px 4px;height:2px;background:rgba(150,120,80,0.2);border-radius:1px"></div>
                <div style="margin:4px 4px;height:2px;background:rgba(150,120,80,0.15);border-radius:1px"></div>
              </div>
            </div>
            <div style="position:absolute;top:50%;left:50%;width:3px;height:90%;transform:translate(-50%,-50%);background:linear-gradient(to bottom,${color[0]},${color[1]});opacity:0.6"></div>`;
        } else {
          el.innerHTML = `
            <div style="position:absolute;inset:0;background:linear-gradient(160deg,${color[1]},${color[0]});border-radius:3px 2px 2px 3px;box-shadow:2px 2px 8px rgba(0,0,0,0.5)">
              <div style="position:absolute;left:0;top:0;bottom:0;width:8px;background:rgba(0,0,0,0.3);border-radius:3px 0 0 3px"></div>
              <div style="position:absolute;left:12px;right:8px;top:10px;height:1px;background:rgba(200,168,74,0.3)"></div>
              <div style="position:absolute;left:12px;right:8px;bottom:10px;height:1px;background:rgba(200,168,74,0.3)"></div>
            </div>`;
        }
        flyingBooksRef.current?.appendChild(el);
      });
    }
  }, []);

  const handleStart = () => {
    if (user) {
      navigate('/library');
    } else {
      navigate('/login');
    }
  };

  return (
    <div className="bg-[#0D0702] min-h-screen text-[#F5EDD8] font-sans">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-[url('/background.jpg')] bg-cover bg-center opacity-40"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-[#080401]/70 via-[#0c0602]/50 to-[#050200]/95 z-10"></div>
        
        <div ref={flyingBooksRef} className="absolute inset-0 z-20 pointer-events-none overflow-hidden"></div>

        <div className="relative z-30 text-center px-6 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-5 py-2 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-200 text-xs tracking-widest uppercase font-semibold mb-8 backdrop-blur-md">
            ✦ AI 감성 에세이 서비스 ✦
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold leading-tight mb-6 drop-shadow-2xl font-serif">
            당신의 하루가 <br />
            <em className="text-amber-300 not-italic drop-shadow-[0_0_30px_rgba(252,211,77,0.5)]">아름다운 에세이로</em> <br />
            남습니다
          </h1>
          <p className="text-lg text-amber-100/70 leading-relaxed mb-10 font-light max-w-lg mx-auto">
            사진 한 장, 잠깐의 감정 표현만으로<br />
            AI가 당신만의 감성적인 이야기를 써드립니다
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={handleStart}
              className="px-10 py-4 bg-gradient-to-br from-amber-400 to-amber-600 text-stone-900 rounded-full font-bold text-lg hover:scale-105 transition-transform shadow-[0_8px_32px_rgba(251,191,36,0.3)]"
            >
              ✦ 나의 도서관 열기
            </button>
            <button 
              onClick={() => navigate('/library')}
              className="px-10 py-4 bg-white/5 border border-amber-500/30 text-amber-100/90 rounded-full font-medium text-lg hover:bg-amber-500/10 transition-colors backdrop-blur-md"
            >
              내 서재 보기
            </button>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-amber-500/50 text-xs tracking-widest z-30 animate-bounce">
          <div className="w-px h-10 bg-gradient-to-b from-transparent to-amber-500/50"></div>
          SCROLL
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-6 bg-[#1A0C05] relative border-y border-amber-900/30">
        <div className="text-center text-xs tracking-widest uppercase text-amber-500 font-semibold mb-4">핵심 기능</div>
        <h2 className="text-3xl md:text-4xl font-bold text-[#F0DEC8] text-center mb-4 font-serif">당신의 일상을 기록하는<br/>가장 아름다운 방법</h2>
        <p className="text-center text-amber-200/60 max-w-lg mx-auto mb-16 font-light">SNS와 다릅니다. 당신의 글이 쌓여 하나의 인생 도서관이 됩니다.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {[
            { icon: '📸', title: '찍는 순간, 이야기가 시작됩니다', desc: '카메라를 열고 셔터를 누르는 순간 AI가 장면을 분석해 감성적인 에세이를 30초 안에 완성합니다.' },
            { icon: '✍️', title: '나만의 글쓰기 페르소나', desc: '시적인 스타일, 담백한 일상체, 브이로그 형식까지. AI가 당신의 글쓰기 습관을 학습합니다.' },
            { icon: '📚', title: '당신만의 인생 도서관', desc: '일상, 여행, 가족, 반려동물... 에세이들이 아름다운 책장에 정렬됩니다. 10년 후 꺼내보는 자서전.' },
            { icon: '🌐', title: 'SNS 공유, 더 아름답게', desc: '인스타그램, 카카오톡에 최적화된 아름다운 이미지로 변환해 공유하세요.' },
            { icon: '🎭', title: '브이로그·자서전·에세이 변환', desc: '같은 순간을 감성 에세이, 브이로그 스크립트, 자서전 형식으로 바꿔드립니다.' },
            { icon: '🎙️', title: '음성으로도 기록하세요', desc: '마이크 버튼 하나로 말하면 AI가 자동으로 텍스트로 변환해 에세이를 작성합니다.' }
          ].map((feat, idx) => (
            <div key={idx} className="bg-white/5 border border-amber-500/10 rounded-2xl p-8 hover:bg-amber-500/10 hover:-translate-y-1 transition-all">
              <div className="text-3xl mb-4">{feat.icon}</div>
              <h3 className="text-lg font-bold text-[#F0DEC8] mb-3">{feat.title}</h3>
              <p className="text-sm text-amber-200/60 leading-relaxed font-light">{feat.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 px-6 bg-gradient-to-b from-[#1A0C05] to-[#2C1508]">
        <div className="text-center text-xs tracking-widest uppercase text-amber-500 font-semibold mb-4">사용 방법</div>
        <h2 className="text-3xl md:text-4xl font-bold text-[#F0DEC8] text-center mb-16 font-serif">딱 4단계면 충분합니다</h2>
        
        <div className="flex flex-col md:flex-row gap-8 max-w-4xl mx-auto relative">
          <div className="hidden md:block absolute top-10 left-[10%] right-[10%] h-px bg-gradient-to-r from-transparent via-amber-500/40 to-transparent"></div>
          {[
            { step: '📷', title: '사진 촬영', desc: '앱에서 직접 찍거나\n기존 사진을 올리세요' },
            { step: '💭', title: '감정 선택', desc: '지금 기분이 어떤가요?\n한 단어로 표현해보세요' },
            { step: '✨', title: 'AI 에세이 생성', desc: '30초 안에 감성적인\n에세이가 완성됩니다' },
            { step: '📤', title: '저장 & 공유', desc: '서재에 보관하거나\nSNS에 공유하세요' }
          ].map((item, idx) => (
            <div key={idx} className="flex-1 text-center relative z-10">
              <div className="w-20 h-20 mx-auto bg-[#1A0C05] border border-amber-500/30 rounded-full flex items-center justify-center text-3xl mb-6 shadow-[0_0_20px_rgba(200,168,74,0.1)]">
                {item.step}
              </div>
              <h4 className="text-lg font-bold text-[#F0DEC8] mb-2">{item.title}</h4>
              <p className="text-sm text-amber-200/50 whitespace-pre-line leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-24 px-6 bg-[#1A0C05] text-center border-t border-amber-500/20">
        <h2 className="text-3xl md:text-4xl font-bold text-[#F0DEC8] mb-4 font-serif">오늘의 첫 에세이를<br/>만들어보세요</h2>
        <p className="text-amber-200/50 mb-10">사진 한 장이면 충분합니다. 무료로 시작하세요.</p>
        <button 
          onClick={handleStart}
          className="px-10 py-4 bg-gradient-to-br from-amber-400 to-amber-600 text-stone-900 rounded-full font-bold text-lg hover:scale-105 transition-transform shadow-lg"
        >
          지금 시작하기 →
        </button>
      </section>
    </div>
  );
};

export default Landing;
