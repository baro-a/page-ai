// Firebase 연동 해제 (완전 삭제)
export const db = {
  collection: () => ({}),
  doc: () => ({}),
} as any;

export const auth = {
  currentUser: null,
  onAuthStateChanged: (callback: any) => {
    // 초기 로딩 후 로그아웃 상태로 시작
    setTimeout(() => callback(null), 100);
    return () => {};
  },
  signOut: async () => {
    window.location.href = '/login';
  },
} as any;

export const googleProvider = {} as any;
export const facebookProvider = {} as any;

console.log("Firebase has been completely disconnected and removed.");
