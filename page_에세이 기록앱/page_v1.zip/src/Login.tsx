import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
// Firebase import 제거

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegister, setIsRegister] = useState(false);
  const [error, setError] = useState('');
  const { profile, setMockAdmin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (profile) {
      navigate('/library');
    }
  }, [profile, navigate]);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // 관리자 로컬 로그인 (네트워크 요청 없음)
    if (email === 'one123' && password === 'pwone123') {
      setMockAdmin();
      return;
    }

    setError('아이디 또는 비밀번호가 일치하지 않습니다.');
  };

  const handleGoogleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleFacebookLogin = async () => {
    try {
      await signInWithPopup(auth, facebookProvider);
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-stone-900 text-stone-200 p-4">
      <div className="bg-stone-800 p-8 rounded-2xl shadow-xl w-full max-w-md border border-stone-700">
        <h2 className="text-3xl font-bold mb-6 text-center text-amber-500">
          {isRegister ? '회원가입' : '로그인'}
        </h2>
        
        {error && <p className="text-red-400 text-sm mb-4 text-center">{error}</p>}

        <form onSubmit={handleEmailAuth} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1 text-stone-400">이메일 또는 ID</label>
            <input 
              type="text" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              className="w-full p-3 rounded-xl bg-stone-900 border border-stone-600 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors"
              placeholder="이메일 주소"
              required 
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1 text-stone-400">비밀번호</label>
            <input 
              type="password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              className="w-full p-3 rounded-xl bg-stone-900 border border-stone-600 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors"
              required 
            />
          </div>
          <button 
            type="submit" 
            className="w-full py-3 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-bold rounded-xl transition-all shadow-lg shadow-amber-900/20"
          >
            {isRegister ? '가입하기' : '로그인'}
          </button>
        </form>

        <div className="mt-6 flex items-center justify-center space-x-4">
          <div className="h-px bg-stone-700 flex-1"></div>
          <span className="text-stone-500 text-sm">또는</span>
          <div className="h-px bg-stone-700 flex-1"></div>
        </div>

        <div className="mt-6 space-y-3">
          <button 
            onClick={handleGoogleLogin} 
            className="w-full py-3 bg-white text-stone-900 font-semibold rounded-xl flex items-center justify-center gap-3 hover:bg-stone-100 transition-colors"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-5 h-5" />
            Google로 계속하기
          </button>
          <button 
            onClick={handleFacebookLogin} 
            className="w-full py-3 bg-[#1877F2] text-white font-semibold rounded-xl flex items-center justify-center gap-3 hover:bg-[#0D6CE0] transition-colors"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/facebook.svg" alt="Facebook" className="w-5 h-5" />
            Facebook으로 계속하기
          </button>
        </div>

        <p className="mt-8 text-center text-sm text-stone-400">
          {isRegister ? '이미 계정이 있으신가요?' : '계정이 없으신가요?'}
          <button 
            onClick={() => setIsRegister(!isRegister)} 
            className="ml-2 text-amber-500 hover:text-amber-400 font-semibold underline underline-offset-4"
          >
            {isRegister ? '로그인하기' : '회원가입하기'}
          </button>
        </p>
      </div>
    </div>
  );
};

export default Login;
