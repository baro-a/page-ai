import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from './firebase';
import { useAuth } from './AuthContext';

interface Essay {
  id: string;
  title: string;
  body: string;
  emotion: string;
  category: string;
  date: string;
  image?: string;
  imgType?: string;
  authorId: string;
}

const EssayDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [essay, setEssay] = useState<Essay | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editBody, setEditBody] = useState('');
  const [showShare, setShowShare] = useState(false);

  useEffect(() => {
    const fetchEssay = async () => {
      if (!id || !profile) return;
      try {
        // 로컬 스토리지에서 에세이 찾기
        const savedEssays = localStorage.getItem(`essays_${profile.uid}`);
        if (savedEssays) {
          const essays: Essay[] = JSON.parse(savedEssays);
          const found = essays.find(e => e.id === id);
          if (found) {
            setEssay(found);
            setEditTitle(found.title);
            setEditBody(found.body);
          } else {
            alert('에세이를 찾을 수 없습니다.');
            navigate('/library');
          }
        } else {
          alert('에세이를 찾을 수 없습니다.');
          navigate('/library');
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchEssay();
  }, [id, profile, navigate]);

  const handleSave = async () => {
    if (!essay || !id || !profile) return;
    try {
      const savedEssays = localStorage.getItem(`essays_${profile.uid}`);
      if (savedEssays) {
        const essays: Essay[] = JSON.parse(savedEssays);
        const updatedEssays = essays.map(e => 
          e.id === id ? { ...e, title: editTitle, body: editBody } : e
        );
        localStorage.setItem(`essays_${profile.uid}`, JSON.stringify(updatedEssays));
        setEssay({ ...essay, title: editTitle, body: editBody });
        setIsEditing(false);
        alert('저장되었습니다.');
      }
    } catch (err) {
      console.error(err);
      alert('저장에 실패했습니다.');
    }
  };

  const handleDelete = async () => {
    if (!id || !profile || !window.confirm('정말 삭제하시겠습니까?')) return;
    try {
      const savedEssays = localStorage.getItem(`essays_${profile.uid}`);
      if (savedEssays) {
        const essays: Essay[] = JSON.parse(savedEssays);
        const filteredEssays = essays.filter(e => e.id !== id);
        localStorage.setItem(`essays_${profile.uid}`, JSON.stringify(filteredEssays));
        alert('삭제되었습니다.');
        navigate('/library');
      }
    } catch (err) {
      console.error(err);
      alert('삭제에 실패했습니다.');
    }
  };

  const shareUrl = window.location.href;
  const shareText = `${essay?.title}\n\n${essay?.body.slice(0, 100)}...\n\n#Page에세이 #AI글쓰기`;

  const handleShareKakao = () => {
    // 실제 카카오톡 공유는 Kakao SDK 초기화가 필요합니다.
    // 여기서는 Web Share API를 우선 시도하거나 안내 메시지를 띄웁니다.
    if (navigator.share) {
      navigator.share({
        title: essay?.title,
        text: shareText,
        url: shareUrl
      }).catch(console.error);
    } else {
      alert('카카오톡 공유 기능은 카카오 디벨로퍼스 앱 키 설정 후 활성화됩니다.');
    }
  };

  const handleShareFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank', 'width=600,height=400');
  };

  const handleShareX = () => {
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`, '_blank', 'width=600,height=400');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      alert('링크가 복사되었습니다.');
    });
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center text-amber-500">불러오는 중...</div>;
  if (!essay) return null;

  const isOwner = profile?.uid === essay.authorId;

  return (
    <div className="max-w-5xl mx-auto p-6 text-stone-200">
      <button onClick={() => navigate('/library')} className="text-amber-500 hover:text-amber-400 mb-6 flex items-center gap-2">
        ← 서재로 돌아가기
      </button>

      <div className="bg-white rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row min-h-[600px]">
        {/* Left: Image & Meta */}
        <div className="md:w-1/2 bg-stone-100 flex flex-col relative">
          <div className="h-80 md:h-full bg-stone-200 flex items-center justify-center overflow-hidden">
            {essay.image ? (
              <img src={essay.image} alt={essay.title} className="w-full h-full object-cover" />
            ) : (
              <span className="text-6xl">📝</span>
            )}
          </div>
          <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/80 to-transparent p-8 text-white">
            <div className="inline-block px-4 py-1.5 bg-amber-500/90 text-stone-900 text-xs font-bold rounded-full mb-4 backdrop-blur-sm">
              {essay.emotion}
            </div>
            <div className="flex flex-col gap-2 text-sm text-stone-200">
              <span>📅 {essay.date}</span>
              <span>📔 {essay.category}</span>
            </div>
          </div>
        </div>

        {/* Right: Content */}
        <div className="md:w-1/2 bg-white p-8 md:p-12 flex flex-col text-stone-800">
          {isEditing ? (
            <>
              <input 
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                className="text-2xl md:text-3xl font-bold font-serif mb-6 border-b border-stone-300 pb-2 outline-none focus:border-amber-500 bg-transparent"
                placeholder="제목"
              />
              <textarea 
                value={editBody}
                onChange={(e) => setEditBody(e.target.value)}
                className="flex-1 text-stone-600 leading-loose resize-none outline-none focus:ring-1 focus:ring-amber-500/50 p-4 rounded-xl bg-stone-50 border border-stone-200"
              />
              <div className="flex gap-4 mt-8">
                <button onClick={() => setIsEditing(false)} className="flex-1 py-3 border border-stone-300 rounded-xl font-bold hover:bg-stone-50">취소</button>
                <button onClick={handleSave} className="flex-1 py-3 bg-amber-600 text-white font-bold rounded-xl hover:bg-amber-700">저장</button>
              </div>
            </>
          ) : (
            <>
              <h1 className="text-2xl md:text-3xl font-bold font-serif mb-8 text-stone-900">{essay.title}</h1>
              <div className="flex-1 text-stone-600 leading-loose whitespace-pre-wrap overflow-y-auto pr-4">
                {essay.body}
              </div>
              
              {isOwner && (
                <div className="mt-8 pt-6 border-t border-stone-100">
                  <div className="flex flex-wrap gap-3 mb-4">
                    <button onClick={() => setIsEditing(true)} className="px-6 py-2.5 bg-stone-100 text-stone-700 font-bold rounded-xl hover:bg-stone-200 transition-colors">
                      ✏️ 수정
                    </button>
                    <button onClick={() => setShowShare(!showShare)} className="px-6 py-2.5 bg-amber-100 text-amber-800 font-bold rounded-xl hover:bg-amber-200 transition-colors">
                      📤 공유
                    </button>
                    <button onClick={handleDelete} className="px-6 py-2.5 bg-red-50 text-red-600 font-bold rounded-xl hover:bg-red-100 transition-colors ml-auto">
                      🗑️ 삭제
                    </button>
                  </div>

                  {showShare && (
                    <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 animate-fade-in">
                      <p className="text-sm font-bold text-stone-700 mb-3">공유 플랫폼 선택</p>
                      <div className="flex gap-3 flex-wrap">
                        <button onClick={handleShareKakao} className="w-12 h-12 rounded-full bg-[#FEE500] text-[#191919] flex items-center justify-center text-xl hover:scale-110 transition-transform shadow-sm">
                          💬
                        </button>
                        <button onClick={handleShareFacebook} className="w-12 h-12 rounded-full bg-[#1877F2] text-white flex items-center justify-center text-xl hover:scale-110 transition-transform shadow-sm">
                          📘
                        </button>
                        <button onClick={handleShareX} className="w-12 h-12 rounded-full bg-black text-white flex items-center justify-center text-xl hover:scale-110 transition-transform shadow-sm">
                          𝕏
                        </button>
                        <button onClick={handleCopyLink} className="w-12 h-12 rounded-full bg-stone-600 text-white flex items-center justify-center text-xl hover:scale-110 transition-transform shadow-sm">
                          🔗
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default EssayDetail;
