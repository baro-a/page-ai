import React, { useEffect, useState } from 'react';
import { useAuth } from './AuthContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from './firebase';

const Subscription: React.FC = () => {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleSubscribe = async (plan: 'premium' | 'pro') => {
    if (!profile) return;
    setLoading(true);
    setMessage('');
    try {
      // 가상 결제 로직 (실제 PG 연동은 추후 진행)
      const docRef = doc(db, 'users', profile.uid);
      await updateDoc(docRef, {
        plan: plan,
        subscriptionStartDate: new Date().toISOString()
      });
      setMessage(`${plan === 'premium' ? '프리미엄' : '프로'} 플랜 구독이 완료되었습니다!`);
    } catch (err: any) {
      setMessage('구독 처리 중 오류가 발생했습니다: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleOrderHardcover = async () => {
    if (!profile) return;
    setLoading(true);
    setMessage('');
    try {
      if (profile.plan === 'free') {
        setMessage('양장본 에세이북은 구독자 전용 서비스입니다.');
        setLoading(false);
        return;
      }

      const now = new Date();
      const subStart = profile.subscriptionStartDate ? new Date(profile.subscriptionStartDate) : null;
      
      // 연간 구독자 (가정: premium/pro 플랜 유지 6개월 이상)
      const isAnnualEligible = subStart && (now.getTime() - subStart.getTime()) > (180 * 24 * 60 * 60 * 1000);

      if (isAnnualEligible && profile.hardcoverCredits > 0) {
        // 크레딧 사용
        const docRef = doc(db, 'users', profile.uid);
        await updateDoc(docRef, {
          hardcoverCredits: profile.hardcoverCredits - 1
        });
        setMessage('연간 구독 혜택(크레딧)으로 고급 양장본 신청이 완료되었습니다!');
      } else {
        // 월간 구독자 또는 크레딧 소진 시 30% 할인 결제
        setMessage('월간 구독자 혜택 적용! 30% 할인된 가격으로 고급 양장본 신청이 완료되었습니다. (가상 결제)');
      }
    } catch (err: any) {
      setMessage('신청 처리 중 오류가 발생했습니다: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto text-stone-200">
      <h2 className="text-3xl font-bold mb-8 text-amber-500 font-serif">구독 및 혜택 관리</h2>
      
      {message && (
        <div className="mb-6 p-4 bg-stone-800 border border-amber-500/30 rounded-xl text-amber-400">
          {message}
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        {/* 현재 구독 정보 */}
        <div className="bg-stone-800 p-6 rounded-2xl border border-stone-700">
          <h3 className="text-xl font-semibold mb-4 text-stone-300">현재 내 플랜</h3>
          <div className="text-4xl font-bold text-amber-500 mb-2 capitalize">
            {profile?.plan || 'Free'}
          </div>
          {profile?.subscriptionStartDate && (
            <p className="text-sm text-stone-500">
              구독 시작일: {new Date(profile.subscriptionStartDate).toLocaleDateString()}
            </p>
          )}
          {profile?.plan !== 'free' && (
            <div className="mt-6 p-4 bg-stone-900/50 rounded-xl border border-stone-700/50">
              <p className="text-sm text-stone-400 mb-1">보유 중인 양장본 크레딧</p>
              <p className="text-2xl font-bold text-stone-200">{profile?.hardcoverCredits || 0}개</p>
              <p className="text-xs text-stone-500 mt-2">* 연간 구독 유지 6개월 경과 시 연 3회 지급</p>
            </div>
          )}
        </div>

        {/* 양장본 신청 */}
        <div className="bg-gradient-to-br from-stone-800 to-stone-900 p-6 rounded-2xl border border-amber-900/50 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10 text-6xl">📚</div>
          <h3 className="text-xl font-semibold mb-2 text-stone-300 relative z-10">나만의 에세이북 (고급 양장본)</h3>
          <p className="text-sm text-stone-400 mb-6 relative z-10">
            당신의 이야기가 담긴 아름다운 실물 책을 받아보세요.
          </p>
          
          <ul className="space-y-3 mb-8 text-sm text-stone-300 relative z-10">
            <li className="flex items-center gap-2">
              <span className="text-amber-500">✓</span> 연간 구독자: 6개월 유지 시 연 3회 무료
            </li>
            <li className="flex items-center gap-2">
              <span className="text-amber-500">✓</span> 월간 구독자: 상시 30% 할인 혜택
            </li>
          </ul>

          <button 
            onClick={handleOrderHardcover}
            disabled={loading}
            className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-stone-900 font-bold rounded-xl transition-colors relative z-10 disabled:opacity-50"
          >
            {loading ? '처리 중...' : '양장본 신청하기'}
          </button>
        </div>
      </div>

      {/* 플랜 업그레이드 */}
      {profile?.plan === 'free' && (
        <div>
          <h3 className="text-xl font-semibold mb-6 text-stone-300">플랜 업그레이드</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-stone-800 p-6 rounded-2xl border border-stone-700 hover:border-amber-500/50 transition-colors">
              <h4 className="text-lg font-bold text-stone-200 mb-2">프리미엄</h4>
              <p className="text-2xl font-bold text-amber-500 mb-4">₩9,900<span className="text-sm text-stone-500 font-normal">/월</span></p>
              <button 
                onClick={() => handleSubscribe('premium')}
                disabled={loading}
                className="w-full py-2 border-2 border-amber-600 text-amber-500 hover:bg-amber-600 hover:text-stone-900 font-bold rounded-xl transition-colors"
              >
                프리미엄 구독 (가상결제)
              </button>
            </div>
            <div className="bg-stone-800 p-6 rounded-2xl border border-stone-700 hover:border-amber-500/50 transition-colors">
              <h4 className="text-lg font-bold text-stone-200 mb-2">프로</h4>
              <p className="text-2xl font-bold text-amber-500 mb-4">₩19,900<span className="text-sm text-stone-500 font-normal">/월</span></p>
              <button 
                onClick={() => handleSubscribe('pro')}
                disabled={loading}
                className="w-full py-2 border-2 border-amber-600 text-amber-500 hover:bg-amber-600 hover:text-stone-900 font-bold rounded-xl transition-colors"
              >
                프로 구독 (가상결제)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Subscription;
